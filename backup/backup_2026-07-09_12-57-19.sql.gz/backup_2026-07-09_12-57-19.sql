--
-- PostgreSQL database dump
--

\restrict wRMV5jpU0gEG9M2Pe0iB3m1wahmMr6WuL13DXCRfNNzQp2umKqM3KR8aUF8wa0d

-- Dumped from database version 15.17
-- Dumped by pg_dump version 17.10 (Debian 17.10-0+deb13u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid_generate_v7(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.uuid_generate_v7() RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE
    timestamp_ms BIGINT := (EXTRACT(EPOCH FROM clock_timestamp()) * 1000)::BIGINT;
    random_bytes BYTEA := gen_random_bytes(10);
    uuid_bytes BYTEA;
BEGIN
    uuid_bytes := 
        set_byte(set_byte(set_byte(set_byte(set_byte(set_byte('\x000000000000'::bytea,
            0, ((timestamp_ms >> 40) & 255)::int),
            1, ((timestamp_ms >> 32) & 255)::int),
            2, ((timestamp_ms >> 24) & 255)::int),
            3, ((timestamp_ms >> 16) & 255)::int),
            4, ((timestamp_ms >> 8) & 255)::int),
            5, (timestamp_ms & 255)::int) ||
        set_byte(set_byte('\x0000'::bytea, 0, ((7 << 4) | ((timestamp_ms >> 8) & 15))::int), 1, get_byte(random_bytes, 0)) ||
        substring(random_bytes, 2, 8);
    RETURN encode(uuid_bytes, 'hex')::UUID;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: backup_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.backup_config (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    gdrive_refresh_token text,
    gdrive_backup_folder_id text,
    gdrive_auth_email text,
    schedule_enabled boolean DEFAULT false NOT NULL,
    schedule_time time without time zone DEFAULT '22:00:00'::time without time zone NOT NULL,
    retention_daily integer DEFAULT 7 NOT NULL,
    retention_weekly integer DEFAULT 4 NOT NULL,
    retention_monthly integer DEFAULT 12 NOT NULL,
    last_backup_at timestamp with time zone,
    last_backup_status character varying(20) DEFAULT 'never'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: backup_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.backup_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    job_type character varying(10) NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    file_name text,
    file_size bigint,
    error_message text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    completed_at timestamp with time zone,
    CONSTRAINT backup_jobs_job_type_check CHECK (((job_type)::text = ANY ((ARRAY['backup'::character varying, 'restore'::character varying])::text[]))),
    CONSTRAINT backup_jobs_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'dump'::character varying, 'uploading'::character varying, 'downloading'::character varying, 'restoring'::character varying, 'completed'::character varying, 'failed'::character varying])::text[])))
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id uuid DEFAULT public.uuid_generate_v7() NOT NULL,
    user_id uuid NOT NULL,
    name text NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: customer_ledger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_ledger (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    customer_id uuid NOT NULL,
    invoice_id uuid,
    entry_type text NOT NULL,
    debit numeric(12,2) DEFAULT 0 NOT NULL,
    credit numeric(12,2) DEFAULT 0 NOT NULL,
    balance numeric(12,2) DEFAULT 0 NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT customer_ledger_entry_type_check CHECK ((entry_type = ANY (ARRAY['invoice'::text, 'payment'::text, 'return'::text, 'opening'::text])))
);


--
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name text NOT NULL,
    phone text NOT NULL,
    email text,
    gstin text,
    address text,
    credit_limit numeric(12,2) DEFAULT 0 NOT NULL,
    opening_balance numeric(12,2) DEFAULT 0 NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT customers_phone_check CHECK ((phone ~ '^[0-9]{10,15}$'::text)),
    CONSTRAINT customers_status_check CHECK ((status = ANY (ARRAY['active'::text, 'inactive'::text])))
);


--
-- Name: inventory_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_batches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    product_id uuid NOT NULL,
    batch_number character varying(100) NOT NULL,
    initial_qty integer NOT NULL,
    remaining_qty integer NOT NULL,
    cost_price numeric(10,2) NOT NULL,
    selling_price numeric(10,2) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    retail_price numeric(10,2),
    vendor_name character varying(100),
    original_quantity integer NOT NULL
);


--
-- Name: invoice_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    invoice_id uuid NOT NULL,
    product_id uuid NOT NULL,
    batch_id uuid,
    product_name_snapshot text NOT NULL,
    hsn_code_snapshot text,
    unit_snapshot text NOT NULL,
    quantity numeric(12,3) NOT NULL,
    unit_price numeric(12,2) NOT NULL,
    cost_price_snapshot numeric(12,2),
    gst_rate_snapshot numeric(5,2) DEFAULT 0 NOT NULL,
    gst_amount numeric(12,2) DEFAULT 0 NOT NULL,
    discount_amount numeric(12,2) DEFAULT 0 NOT NULL,
    line_total numeric(12,2) NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT invoice_items_quantity_check CHECK ((quantity > (0)::numeric)),
    CONSTRAINT invoice_items_unit_price_check CHECK ((unit_price >= (0)::numeric))
);


--
-- Name: invoice_returns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_returns (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    invoice_id uuid NOT NULL,
    invoice_item_id uuid,
    product_id uuid NOT NULL,
    batch_id uuid,
    qty_returned numeric(12,3) NOT NULL,
    refund_amount numeric(12,2) NOT NULL,
    restock_qty numeric(12,3) DEFAULT 0 NOT NULL,
    reason text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT invoice_returns_qty_returned_check CHECK ((qty_returned > (0)::numeric)),
    CONSTRAINT invoice_returns_refund_amount_check CHECK ((refund_amount >= (0)::numeric))
);


--
-- Name: invoice_sequences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_sequences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    year text NOT NULL,
    prefix text DEFAULT 'INV'::text NOT NULL,
    last_number integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    invoice_number text NOT NULL,
    customer_id uuid,
    customer_name_snapshot text,
    customer_phone_snapshot text,
    customer_gstin_snapshot text,
    subtotal numeric(12,2) DEFAULT 0 NOT NULL,
    discount_amount numeric(12,2) DEFAULT 0 NOT NULL,
    total_gst numeric(12,2) DEFAULT 0 NOT NULL,
    round_off numeric(4,2) DEFAULT 0 NOT NULL,
    grand_total numeric(12,2) DEFAULT 0 NOT NULL,
    amount_paid numeric(12,2) DEFAULT 0 NOT NULL,
    balance_due numeric(12,2) DEFAULT 0 NOT NULL,
    invoice_status text DEFAULT 'completed'::text NOT NULL,
    payment_status text DEFAULT 'paid'::text NOT NULL,
    notes text,
    billed_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT invoices_invoice_status_check CHECK ((invoice_status = ANY (ARRAY['completed'::text, 'cancelled'::text, 'returned'::text, 'deleted'::text]))),
    CONSTRAINT invoices_payment_status_check CHECK ((payment_status = ANY (ARRAY['paid'::text, 'partial'::text, 'pending'::text])))
);


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    filename character varying(255) NOT NULL,
    executed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: password_resets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.password_resets (
    id uuid DEFAULT public.uuid_generate_v7() NOT NULL,
    user_id uuid NOT NULL,
    token text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: payment_receipt_sequences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_receipt_sequences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    year text NOT NULL,
    prefix text DEFAULT 'PAY'::text NOT NULL,
    last_number integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: payment_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_receipts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    customer_id uuid NOT NULL,
    ledger_id uuid NOT NULL,
    receipt_number text NOT NULL,
    amount numeric(12,2) NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT payment_receipts_amount_check CHECK ((amount > (0)::numeric))
);


--
-- Name: product_daily_sales; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_daily_sales (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    product_id uuid NOT NULL,
    sale_date date NOT NULL,
    quantity integer NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT product_daily_sales_quantity_check CHECK ((quantity > 0))
);


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id uuid DEFAULT public.uuid_generate_v7() NOT NULL,
    user_id uuid NOT NULL,
    category_id uuid NOT NULL,
    subcategory_id uuid,
    name text NOT NULL,
    unit text NOT NULL,
    hsn_code text,
    gst_rate numeric(5,2) DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    daily_sales integer DEFAULT 0,
    lead_time integer DEFAULT 0,
    emergency_stock integer DEFAULT 0,
    rop integer DEFAULT 0,
    alert_triggered boolean DEFAULT false,
    CONSTRAINT products_gst_rate_check CHECK ((gst_rate >= (0)::numeric))
);


--
-- Name: purchases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchases (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    vendor_id uuid,
    total_amount numeric(10,2) DEFAULT 0.00 NOT NULL,
    paid_amount numeric(10,2) DEFAULT 0.00 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: stock_list; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_list (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    product_id uuid NOT NULL,
    quantity integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_movements (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    batch_id uuid,
    product_id uuid NOT NULL,
    reference_type text NOT NULL,
    reference_id uuid,
    movement_type text NOT NULL,
    qty numeric(12,3) NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT stock_movements_movement_type_check CHECK ((movement_type = ANY (ARRAY['IN'::text, 'OUT'::text]))),
    CONSTRAINT stock_movements_qty_check CHECK ((qty > (0)::numeric)),
    CONSTRAINT stock_movements_reference_type_check CHECK ((reference_type = ANY (ARRAY['PURCHASE'::text, 'SALE'::text, 'RETURN'::text, 'ADJUSTMENT'::text])))
);


--
-- Name: subcategories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subcategories (
    id uuid DEFAULT public.uuid_generate_v7() NOT NULL,
    user_id uuid NOT NULL,
    category_id uuid NOT NULL,
    name text NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v7() NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    full_name text,
    is_active boolean DEFAULT true,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: vendor_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendor_payments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    purchase_id uuid NOT NULL,
    amount numeric(12,2) NOT NULL,
    payment_date timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT vendor_payments_amount_check CHECK ((amount > (0)::numeric))
);


--
-- Name: vendor_purchase_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendor_purchase_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    purchase_id uuid NOT NULL,
    product_id uuid NOT NULL,
    product_name_snapshot text NOT NULL,
    quantity numeric(12,3) NOT NULL,
    unit_cost numeric(12,2) NOT NULL,
    gst_rate numeric(5,2) DEFAULT 0 NOT NULL,
    CONSTRAINT vendor_purchase_items_gst_rate_check CHECK ((gst_rate >= (0)::numeric)),
    CONSTRAINT vendor_purchase_items_quantity_check CHECK ((quantity > (0)::numeric)),
    CONSTRAINT vendor_purchase_items_unit_cost_check CHECK ((unit_cost >= (0)::numeric))
);


--
-- Name: vendor_purchases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendor_purchases (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    vendor_id uuid NOT NULL,
    invoice_number text,
    total_amount numeric(12,2) DEFAULT 0 NOT NULL,
    amount_paid numeric(12,2) DEFAULT 0 NOT NULL,
    purchase_date timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT vendor_purchases_amount_paid_check CHECK ((amount_paid >= (0)::numeric)),
    CONSTRAINT vendor_purchases_total_amount_check CHECK ((total_amount >= (0)::numeric))
);


--
-- Name: vendors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendors (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name text NOT NULL,
    contact_info text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT vendors_contact_info_check CHECK ((contact_info ~ '^[0-9]{10,15}$'::text))
);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Data for Name: backup_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.backup_config (id, user_id, gdrive_refresh_token, gdrive_backup_folder_id, gdrive_auth_email, schedule_enabled, schedule_time, retention_daily, retention_weekly, retention_monthly, last_backup_at, last_backup_status, created_at, updated_at) FROM stdin;
149239f6-1281-445f-96bc-738f66385aa7	019f085a-3064-70f4-7264-abe1b57813df	1//0gd2qUcqESSCtCgYIARAAGBASNwF-L9IrZOOSKFn_FmHiiwyEBicNUtSeexHnUzQRkpbwbybGthBTfiobFbXrgfxufLSfMAwvWH8	\N	\N	f	22:00:00	7	4	12	\N	never	2026-07-08 17:58:27.212742+00	2026-07-09 11:40:04.013965+00
\.


--
-- Data for Name: backup_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.backup_jobs (id, user_id, job_type, status, file_name, file_size, error_message, created_at, completed_at) FROM stdin;
5fea1ee4-634a-4f74-ae5a-ec1e8d7c37a2	019f085a-3064-70f4-7264-abe1b57813df	backup	failed	\N	\N	Job was stuck due to worker PDO bug (SQLSTATE[HY093]), fixed in latest deploy	2026-07-09 11:41:29.933872+00	2026-07-09 12:06:15.68784+00
725c6f85-840d-4356-bf99-39cb7d985a48	019f085a-3064-70f4-7264-abe1b57813df	backup	failed	\N	\N	Job was stuck due to worker PDO bug (SQLSTATE[HY093]), fixed in latest deploy	2026-07-09 11:52:51.949202+00	2026-07-09 12:06:15.68784+00
06978c8b-99f5-4172-af27-b8721b22a89e	019f085a-3064-70f4-7264-abe1b57813df	backup	failed	\N	\N	Job was stuck due to worker PDO bug (fixed)	2026-07-09 12:01:40.997173+00	2026-07-09 12:06:15.68784+00
1bac12ec-c094-4f63-a511-3fcaa258be10	019f085a-3064-70f4-7264-abe1b57813df	backup	failed	backup_2026-07-09_12-09-21.sql.gz	\N	SQLSTATE[42704]: Undefined object: 7 ERROR:  unrecognized configuration parameter "app.current_user_id"	2026-07-09 12:09:21.842737+00	2026-07-09 12:09:21.868962+00
0f1e1d26-bfcc-4180-828b-d4d865dabb5b	e165e33e-0b13-4db9-93bb-79858a78a74a	backup	failed	backup_2026-07-09_12-11-50.sql.gz	\N	Google Drive not authenticated	2026-07-09 12:11:50.628945+00	2026-07-09 12:11:50.64964+00
fb8bf8d4-daa9-4742-9335-09080a8fb3f8	019f085a-3064-70f4-7264-abe1b57813df	backup	failed	backup_2026-07-09_12-12-26.sql.gz	\N	{\n  "error": {\n    "code": 401,\n    "message": "Request is missing required authentication credential. Expected OAuth 2 access token, login cookie or other valid authentication credential. See https://developers.google.com/identity/sign-in/web/devconsole-project.",\n    "errors": [\n      {\n        "message": "Login Required.",\n        "domain": "global",\n        "reason": "required",\n        "location": "Authorization",\n        "locationType": "header"\n      }\n    ],\n    "status": "UNAUTHENTICATED",\n    "details": [\n      {\n        "@type": "type.googleapis.com/google.rpc.ErrorInfo",\n        "reason": "CREDENTIALS_MISSING",\n        "domain": "googleapis.com",\n        "metadata": {\n          "method": "google.apps.drive.v3.DriveFiles.Create",\n          "service": "drive.googleapis.com"\n        }\n      }\n    ]\n  }\n}\n	2026-07-09 12:12:26.580641+00	2026-07-09 12:12:27.284754+00
5a06e073-373f-4f5c-b8ad-e1586dd5d9d4	019f085a-3064-70f4-7264-abe1b57813df	backup	completed	backup_2026-07-09_12-15-09.sql.gz	\N	\N	2026-07-09 12:15:09.950453+00	2026-07-09 12:15:13.070599+00
0167e794-918b-44b6-8cf9-0c5859b5eaaa	019f085a-3064-70f4-7264-abe1b57813df	backup	completed	backup_2026-07-09_12-37-21.sql.gz	\N	\N	2026-07-09 12:37:21.583918+00	2026-07-09 12:37:25.704726+00
af0344d1-10c7-4de0-907b-62a7937efabf	019f085a-3064-70f4-7264-abe1b57813df	backup	completed	backup_2026-07-09_12-37-28.sql.gz	\N	\N	2026-07-09 12:37:28.544092+00	2026-07-09 12:37:31.026724+00
a30799c9-1754-4af3-b883-05209bf1f702	019f085a-3064-70f4-7264-abe1b57813df	backup	completed	backup_2026-07-09_12-41-54.sql.gz	\N	\N	2026-07-09 12:41:54.341269+00	2026-07-09 12:41:57.303097+00
fb3ac807-1a0c-4732-900d-fc07c75db852	019f085a-3064-70f4-7264-abe1b57813df	backup	completed	backup_2026-07-09_12-52-22.sql.gz	\N	\N	2026-07-09 12:52:22.175968+00	2026-07-09 12:52:27.669626+00
2cf7a136-af5e-4053-9009-a9b7e5b3ec64	019f085a-3064-70f4-7264-abe1b57813df	backup	dump	backup_2026-07-09_12-57-19.sql.gz	\N	\N	2026-07-09 12:57:19.287401+00	\N
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, user_id, name, created_at) FROM stdin;
a1111111-2222-3333-4444-555555555551	e165e33e-0b13-4db9-93bb-79858a78a74a	Apparel & Textiles	2026-06-26 12:24:37.841601+00
a1111111-2222-3333-4444-555555555552	e165e33e-0b13-4db9-93bb-79858a78a74a	Footwear	2026-06-26 12:24:37.852649+00
a1111111-2222-3333-4444-555555555553	e165e33e-0b13-4db9-93bb-79858a78a74a	Electronics	2026-06-26 12:24:37.857766+00
a1111111-2222-3333-4444-555555555554	e165e33e-0b13-4db9-93bb-79858a78a74a	Home & Kitchen	2026-06-26 12:24:37.8638+00
a1111111-2222-3333-4444-555555555555	e165e33e-0b13-4db9-93bb-79858a78a74a	Books & Stationery	2026-06-26 12:24:37.868978+00
019f0870-1242-7223-6725-3cab29b2a86b	019f085a-3064-70f4-7264-abe1b57813df	stones	2026-06-27 09:36:30.270057+00
019f0871-5e20-7e31-d6d1-5b43508013e7	019f085a-3064-70f4-7264-abe1b57813df	Embroidary thread	2026-06-27 09:37:55.228836+00
019f194f-182d-78ee-6bbe-b2f8058006bf	019f085a-3064-70f4-7264-abe1b57813df	Lace border	2026-06-30 16:14:01.76628+00
019f37dc-3278-7256-4800-d2a5c84ae44d	019f085a-3064-70f4-7264-abe1b57813df	sewing machines	2026-07-06 14:36:45.555682+00
019f3832-5804-782a-700f-e1ec52a0d1a9	019f085a-3064-70f4-7264-abe1b57813df	Lining	2026-07-06 16:10:51.258092+00
\.


--
-- Data for Name: customer_ledger; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_ledger (id, user_id, customer_id, invoice_id, entry_type, debit, credit, balance, notes, created_at) FROM stdin;
6af6d102-0a79-4173-acbd-6c8dbe2deade	019f085a-3064-70f4-7264-abe1b57813df	1048e40b-e9f5-4890-b3ee-9d5bedf2b7a1	6f89ebfc-0e1e-4258-9c73-011532c3fe8e	invoice	326.00	0.00	326.00	Invoice INV-2026-000017	2026-06-30 19:32:48.633617+00
f642db4e-b505-4d63-9dc9-5276e54f6c57	019f085a-3064-70f4-7264-abe1b57813df	1048e40b-e9f5-4890-b3ee-9d5bedf2b7a1	6f89ebfc-0e1e-4258-9c73-011532c3fe8e	payment	0.00	198.00	128.00	Checkout payment - Invoice INV-2026-000017	2026-06-30 19:32:48.63596+00
d7ad9ae7-3db1-48cd-9110-0ac444581356	019f085a-3064-70f4-7264-abe1b57813df	1048e40b-e9f5-4890-b3ee-9d5bedf2b7a1	\N	payment	0.00	100.00	28.00	partial payment	2026-06-30 19:33:18.723379+00
0dfcc32c-e402-4242-b34f-6c0bd1a7227f	019f085a-3064-70f4-7264-abe1b57813df	1048e40b-e9f5-4890-b3ee-9d5bedf2b7a1	\N	payment	0.00	28.00	0.00	cleared	2026-07-01 08:46:18.32615+00
6fc69c4f-4185-40e5-bf23-60bb00bcc84b	019f085a-3064-70f4-7264-abe1b57813df	8d24bfca-aa8e-49e3-9146-b2a358bbef94	\N	opening	2000.00	0.00	2000.00	Opening balance	2026-07-01 08:54:15.326124+00
07277ff9-dbdc-4308-8c42-4a76f62ec69f	019f085a-3064-70f4-7264-abe1b57813df	8d24bfca-aa8e-49e3-9146-b2a358bbef94	\N	payment	0.00	1000.00	1000.00	partial	2026-07-01 08:54:25.788686+00
3cc02d17-65e0-4034-9bf4-544dfdaf524d	019f085a-3064-70f4-7264-abe1b57813df	8d24bfca-aa8e-49e3-9146-b2a358bbef94	\N	payment	0.00	1000.00	0.00	done	2026-07-04 07:52:23.870444+00
063543c1-949b-4ee1-a8cb-25fc6e9e70c0	019f085a-3064-70f4-7264-abe1b57813df	8d24bfca-aa8e-49e3-9146-b2a358bbef94	cfa68a02-eca3-400a-affa-a3ccc99f3c08	invoice	419.00	0.00	419.00	Invoice INV-2026-000018	2026-07-04 07:56:04.489771+00
246c0a8d-851b-4632-8b19-b5983290d945	019f085a-3064-70f4-7264-abe1b57813df	8d24bfca-aa8e-49e3-9146-b2a358bbef94	cfa68a02-eca3-400a-affa-a3ccc99f3c08	payment	0.00	200.00	219.00	Checkout payment - Invoice INV-2026-000018	2026-07-04 07:56:04.491528+00
8e4130bb-2cb6-4cc5-a3b3-393a01bfc848	019f085a-3064-70f4-7264-abe1b57813df	217ab7ba-8c32-45c8-9659-2126e1fc0c14	56676f9f-64bb-420f-b000-0a446202360c	invoice	509.00	0.00	509.00	Invoice INV-2026-000020	2026-07-06 14:33:16.895759+00
5b56b595-42db-4525-8bf5-ba2cff84f837	019f085a-3064-70f4-7264-abe1b57813df	217ab7ba-8c32-45c8-9659-2126e1fc0c14	56676f9f-64bb-420f-b000-0a446202360c	payment	0.00	250.00	259.00	Checkout payment - Invoice INV-2026-000020	2026-07-06 14:33:16.89789+00
00097164-ff3b-46ad-bc35-7262b382741d	019f085a-3064-70f4-7264-abe1b57813df	289f7c7d-3ec2-4930-81ce-417d3db23358	58f4b302-ce72-476a-a2e6-d0933e4b8bfd	invoice	18500.00	0.00	18500.00	Invoice INV-2026-000021	2026-07-06 14:43:49.482969+00
d81fff68-c10d-4292-bf1d-86dfd85e90a9	019f085a-3064-70f4-7264-abe1b57813df	289f7c7d-3ec2-4930-81ce-417d3db23358	58f4b302-ce72-476a-a2e6-d0933e4b8bfd	payment	0.00	15000.00	3500.00	Checkout payment - Invoice INV-2026-000021	2026-07-06 14:43:49.483784+00
963e7e41-4fb9-428d-bba2-b28140590ee7	019f085a-3064-70f4-7264-abe1b57813df	1048e40b-e9f5-4890-b3ee-9d5bedf2b7a1	03d664db-f4d9-4f2c-a5d5-44edbcd93b98	invoice	322.00	0.00	322.00	Invoice INV-2026-000022	2026-07-06 16:32:26.329137+00
6e401605-1059-432c-92f8-e8495c3e5235	019f085a-3064-70f4-7264-abe1b57813df	1048e40b-e9f5-4890-b3ee-9d5bedf2b7a1	03d664db-f4d9-4f2c-a5d5-44edbcd93b98	payment	0.00	200.00	122.00	Checkout payment - Invoice INV-2026-000022	2026-07-06 16:32:26.329744+00
8886efce-a0f6-47f1-a51d-dd3d92be8844	019f085a-3064-70f4-7264-abe1b57813df	8d24bfca-aa8e-49e3-9146-b2a358bbef94	bdea4861-829c-4917-a519-d27dbf2766e1	invoice	15600.00	0.00	15819.00	Invoice INV-2026-000023	2026-07-07 11:24:32.094466+00
c447ff25-edad-4d46-bae0-25640f57388f	019f085a-3064-70f4-7264-abe1b57813df	8d24bfca-aa8e-49e3-9146-b2a358bbef94	bdea4861-829c-4917-a519-d27dbf2766e1	payment	0.00	10000.00	5819.00	Checkout payment - Invoice INV-2026-000023	2026-07-07 11:24:32.095297+00
9faf37a3-64fe-49f4-b0c5-22c545225788	019f085a-3064-70f4-7264-abe1b57813df	8d24bfca-aa8e-49e3-9146-b2a358bbef94	1a2ea9dc-5da6-4f7e-b3ee-dddb6b367e21	invoice	857.00	0.00	6676.00	Invoice INV-2026-000025	2026-07-08 13:28:10.774755+00
4513d7f6-f1e0-434e-be9f-3bfb83668847	019f085a-3064-70f4-7264-abe1b57813df	8d24bfca-aa8e-49e3-9146-b2a358bbef94	1a2ea9dc-5da6-4f7e-b3ee-dddb6b367e21	payment	0.00	490.00	6186.00	Checkout payment - Invoice INV-2026-000025	2026-07-08 13:28:10.776679+00
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customers (id, user_id, name, phone, email, gstin, address, credit_limit, opening_balance, status, created_at, updated_at) FROM stdin;
1048e40b-e9f5-4890-b3ee-9d5bedf2b7a1	019f085a-3064-70f4-7264-abe1b57813df	Angayarkanni S	09884983412	jayaaish6@gmail.com	\N	15,KC Nayanar street , military line,samathanapuram, Tirunelveli- 02	0.00	0.00	active	2026-06-30 19:32:20.364817+00	2026-06-30 19:32:20.364817+00
8d24bfca-aa8e-49e3-9146-b2a358bbef94	019f085a-3064-70f4-7264-abe1b57813df	surya	9042357007	surya@gmail.com	\N	pettai	0.00	2000.00	active	2026-07-01 08:54:15.310061+00	2026-07-01 08:54:15.310061+00
217ab7ba-8c32-45c8-9659-2126e1fc0c14	019f085a-3064-70f4-7264-abe1b57813df	aishwarya	7530019108	\N	\N	\N	0.00	0.00	active	2026-07-01 10:00:43.204518+00	2026-07-01 10:00:43.204518+00
41896b8e-63cf-423f-a265-cdaf6736419e	019f085a-3064-70f4-7264-abe1b57813df	sudar	9787911108	\N	\N	\N	0.00	0.00	active	2026-07-01 10:01:10.550627+00	2026-07-01 10:01:10.550627+00
289f7c7d-3ec2-4930-81ce-417d3db23358	019f085a-3064-70f4-7264-abe1b57813df	suba	9092926626	\N	\N	\N	0.00	0.00	active	2026-07-01 10:01:44.530624+00	2026-07-01 10:01:44.530624+00
\.


--
-- Data for Name: inventory_batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_batches (id, user_id, product_id, batch_number, initial_qty, remaining_qty, cost_price, selling_price, created_at, updated_at, retail_price, vendor_name, original_quantity) FROM stdin;
0c941b45-998e-4229-b871-33726e67f372	e165e33e-0b13-4db9-93bb-79858a78a74a	c1111111-2222-3333-4444-555555555501	BATCH-501-1782551642-1	68	68	711.00	994.00	2026-06-27 09:14:02+00	2026-06-27 09:14:02.678525+00	1118.00	Test Vendor	68
0b9cf877-d6c6-4902-80e1-3724ba00d10d	e165e33e-0b13-4db9-93bb-79858a78a74a	c1111111-2222-3333-4444-555555555501	BATCH-501-1782551642-2	57	57	834.00	942.00	2026-06-27 09:14:02+00	2026-06-27 09:14:02.737732+00	1021.00	Test Vendor	57
5466a5f1-ce1f-4641-972b-2b3db075d117	e165e33e-0b13-4db9-93bb-79858a78a74a	c1111111-2222-3333-4444-555555555502	BATCH-502-1782551642-1	61	61	340.00	578.00	2026-06-27 09:14:02+00	2026-06-27 09:14:02.805806+00	674.00	Test Vendor	61
52abd2d4-30dd-4cad-ac2c-b66d97fb0571	e165e33e-0b13-4db9-93bb-79858a78a74a	c1111111-2222-3333-4444-555555555502	BATCH-502-1782551642-2	46	46	573.00	816.00	2026-06-27 09:14:02+00	2026-06-27 09:14:02.866364+00	875.00	Test Vendor	46
0151f17e-b0fe-4d32-8d64-276d1b156c2d	e165e33e-0b13-4db9-93bb-79858a78a74a	c1111111-2222-3333-4444-555555555503	BATCH-503-1782551642-1	26	26	460.00	662.00	2026-06-27 09:14:02+00	2026-06-27 09:14:02.946999+00	749.00	Test Vendor	26
2a4b704f-0cc8-42dc-9043-965743f3c115	e165e33e-0b13-4db9-93bb-79858a78a74a	c1111111-2222-3333-4444-555555555504	BATCH-504-1782551643-1	41	41	388.00	607.00	2026-06-27 09:14:03+00	2026-06-27 09:14:03.073021+00	804.00	Test Vendor	41
1e186780-64a6-4fe4-b1fb-15f1cb57537a	e165e33e-0b13-4db9-93bb-79858a78a74a	c1111111-2222-3333-4444-555555555504	BATCH-504-1782551643-2	68	68	281.00	403.00	2026-06-27 09:14:03+00	2026-06-27 09:14:03.116631+00	569.00	Test Vendor	68
91489057-141b-4765-9fe3-d5635ed706cc	e165e33e-0b13-4db9-93bb-79858a78a74a	c1111111-2222-3333-4444-555555555505	BATCH-505-1782551643-1	25	25	554.00	720.00	2026-06-27 09:14:03+00	2026-06-27 09:14:03.160898+00	867.00	Test Vendor	25
fda621b4-46d0-4b38-aef4-c3c1bb957a30	e165e33e-0b13-4db9-93bb-79858a78a74a	c1111111-2222-3333-4444-555555555505	BATCH-505-1782551643-2	28	28	747.00	885.00	2026-06-27 09:14:03+00	2026-06-27 09:14:03.229052+00	1019.00	Test Vendor	28
a2f2c246-4a41-4cbb-aa14-c3b2df47d01c	e165e33e-0b13-4db9-93bb-79858a78a74a	c1111111-2222-3333-4444-555555555506	BATCH-506-1782551643-1	40	40	558.00	709.00	2026-06-27 09:14:03+00	2026-06-27 09:14:03.289416+00	871.00	Test Vendor	40
db61a516-e95d-4106-a92c-a7fb25be7ee7	e165e33e-0b13-4db9-93bb-79858a78a74a	c1111111-2222-3333-4444-555555555506	BATCH-506-1782551643-2	49	49	885.00	1158.00	2026-06-27 09:14:03+00	2026-06-27 09:14:03.339389+00	1276.00	Test Vendor	49
fbc4137d-6e53-4a02-99a1-0b101093e00a	019f085a-3064-70f4-7264-abe1b57813df	019f199a-3a4e-7add-24a3-55605cb81fcd	BL001	51	29	40.00	44.00	2026-06-30 00:00:00+00	2026-07-06 14:33:16.853903+00	50.00	angayarkanni	51
eb3ba330-2acf-45aa-99bf-21d24b015e14	019f085a-3064-70f4-7264-abe1b57813df	019f13c6-d7f4-7716-a073-809189390517	BE002	20	10	12.00	16.00	2026-06-29 00:00:00+00	2026-06-30 09:12:47.359736+00	18.00	angayarkanni	20
6db44d1d-2041-4373-b0e2-bb77ec65b68a	019f085a-3064-70f4-7264-abe1b57813df	019f13c6-d7f4-7716-a073-809189390517	BE001	20	24	10.00	12.00	2026-06-29 00:00:00+00	2026-07-06 14:33:16.853903+00	14.00	surya	20
31829f8a-be0a-4fc1-840d-d7aaf308a922	019f085a-3064-70f4-7264-abe1b57813df	019f3833-e982-7976-0867-1ff6efaa2223	BL001	30	27	50.00	52.00	2026-07-06 00:00:00+00	2026-07-06 16:32:26.314539+00	60.00	Angayarkanni	30
3ca6821b-5e6b-49be-9af6-adca87cf197f	019f085a-3064-70f4-7264-abe1b57813df	019f37dc-c782-775c-9a47-55c139b7f5f5	BSE001	30	5	3000.00	4000.00	2026-07-06 00:00:00+00	2026-07-08 13:20:17.64762+00	5000.00	aishwarya	30
88bb61ba-81d6-4127-bbd0-ec5061ed4a7a	019f085a-3064-70f4-7264-abe1b57813df	019f3840-b80f-788e-d21f-57b23086d62a	BL002	30	11	50.00	52.00	2026-07-06 00:00:00+00	2026-07-08 13:28:10.768729+00	60.00	Angayarkanni	30
4307a5bb-e98d-4fff-a873-ce9b0c434b06	e165e33e-0b13-4db9-93bb-79858a78a74a	c1111111-2222-3333-4444-555555555503	BATCH-503-1782551642-2	48	47	320.00	583.00	2026-06-27 09:14:03+00	2026-06-30 15:51:54.198382+00	708.00	Test Vendor	48
d492e2d0-a046-4671-a899-ab7d5ad94e10	e165e33e-0b13-4db9-93bb-79858a78a74a	c1111111-2222-3333-4444-555555555503	NEW-BATCH-TEST	10	10	100.00	500.00	2026-06-30 17:34:31+00	2026-06-30 17:34:31.680402+00	600.00	Test	10
be7e175f-de8c-4884-99af-149ab7dcc82a	019f085a-3064-70f4-7264-abe1b57813df	019f0872-7e4a-7efe-75ef-27d1fe58fa7f	BS01	20	0	10.00	12.00	2026-06-27 00:00:00+00	2026-07-04 10:21:43.896255+00	15.00	aishwarya	20
30fec261-8de1-4058-8ece-468b3f8cb0f8	019f085a-3064-70f4-7264-abe1b57813df	019f194f-b32d-7322-1603-70ef7d762826	BL001	52	32	40.00	45.00	2026-06-30 00:00:00+00	2026-07-06 14:33:16.853903+00	49.00	suresh traders	52
\.


--
-- Data for Name: invoice_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_items (id, invoice_id, product_id, batch_id, product_name_snapshot, hsn_code_snapshot, unit_snapshot, quantity, unit_price, cost_price_snapshot, gst_rate_snapshot, gst_amount, discount_amount, line_total, created_at) FROM stdin;
a415b7e9-52a1-4b2e-9dc5-6fd091f64633	677e4ef1-1a26-49ff-bab6-c5413b48643e	019f13c6-d7f4-7716-a073-809189390517	6db44d1d-2041-4373-b0e2-bb77ec65b68a	Red thread T01	1221	bundle	1.000	12.00	10.00	10.00	1.20	0.00	13.20	2026-06-30 12:50:43.780025+00
72740e79-0b9c-4737-a05f-2dd0e639bb44	677e4ef1-1a26-49ff-bab6-c5413b48643e	019f0872-7e4a-7efe-75ef-27d1fe58fa7f	be7e175f-de8c-4884-99af-149ab7dcc82a	Gold stones T01	3292	pkt	1.000	12.00	10.00	9.00	1.08	0.00	13.08	2026-06-30 12:50:43.780025+00
3a60700e-bafd-43fe-8c66-3e9cd5ea491f	3331828c-d612-4d58-910f-9e11af9cb29e	019f13c6-d7f4-7716-a073-809189390517	6db44d1d-2041-4373-b0e2-bb77ec65b68a	Red thread T01	1221	bundle	1.000	12.00	10.00	10.00	1.20	0.00	13.20	2026-06-30 15:07:23.920159+00
81eb32ae-cadb-494f-b9a6-3722ec33c27a	3331828c-d612-4d58-910f-9e11af9cb29e	019f0872-7e4a-7efe-75ef-27d1fe58fa7f	be7e175f-de8c-4884-99af-149ab7dcc82a	Gold stones T01	3292	pkt	1.000	12.00	10.00	9.00	1.08	0.00	13.08	2026-06-30 15:07:23.920159+00
936a0bc2-376d-4bbe-9a31-20254eed1bab	a19b37bb-e673-45db-b13a-0a072c209404	019f13c6-d7f4-7716-a073-809189390517	6db44d1d-2041-4373-b0e2-bb77ec65b68a	Red thread T01	1221	bundle	1.000	12.00	10.00	10.00	1.20	0.00	13.20	2026-06-30 15:14:22.203415+00
748c8b47-009c-457f-a0a4-116d743fdf0f	a19b37bb-e673-45db-b13a-0a072c209404	019f0872-7e4a-7efe-75ef-27d1fe58fa7f	be7e175f-de8c-4884-99af-149ab7dcc82a	Gold stones T01	3292	pkt	1.000	12.00	10.00	9.00	1.08	0.00	13.08	2026-06-30 15:14:22.203415+00
4e6db781-19e6-4cb7-aaa4-8b1cfdd1be5e	ea3eb01c-efe0-4dbb-a054-70bd5118bf7b	c1111111-2222-3333-4444-555555555503	4307a5bb-e98d-4fff-a873-ce9b0c434b06	Classic White Sneakers	HSN54321	pairs	1.000	583.00	320.00	12.00	69.96	0.00	652.96	2026-06-30 15:51:54.198382+00
c1588c88-d12e-476c-b082-8e3a50a7c41b	2682423e-1c82-4b57-97c0-2681aadf9a00	019f13c6-d7f4-7716-a073-809189390517	6db44d1d-2041-4373-b0e2-bb77ec65b68a	Red thread T01	1221	bundle	2.000	12.00	10.00	10.00	2.40	0.00	26.40	2026-06-30 16:00:55.378241+00
25c72057-f351-43dd-8ddf-f3835cf4a736	2682423e-1c82-4b57-97c0-2681aadf9a00	019f0872-7e4a-7efe-75ef-27d1fe58fa7f	be7e175f-de8c-4884-99af-149ab7dcc82a	Gold stones T01	3292	pkt	2.000	12.00	10.00	9.00	2.16	0.00	26.16	2026-06-30 16:00:55.378241+00
c0edb8c8-11fa-4695-8eaf-44ffbe675513	d101dd54-f858-43ac-914b-3b96f36a55e9	019f0872-7e4a-7efe-75ef-27d1fe58fa7f	be7e175f-de8c-4884-99af-149ab7dcc82a	Gold stones T01	3292	pkt	1.000	12.00	10.00	9.00	1.08	0.00	13.08	2026-06-30 16:02:27.085409+00
7ca8424b-f2f1-411e-874f-576cf520d885	7e36c091-9ae1-49e8-aa45-cbe47b0a1ca7	019f194f-b32d-7322-1603-70ef7d762826	30fec261-8de1-4058-8ece-468b3f8cb0f8	silver lace border	3029	roll	1.000	45.00	40.00	33.00	14.85	0.00	59.85	2026-06-30 16:18:09.345991+00
feb77523-6eb2-4feb-b6fe-24addffdc5de	8f3e532d-2b71-4b6a-a5e9-b25c6c1a2fbe	019f194f-b32d-7322-1603-70ef7d762826	30fec261-8de1-4058-8ece-468b3f8cb0f8	silver lace border	3029	roll	1.000	45.00	40.00	33.00	14.85	0.00	59.85	2026-06-30 16:35:08.894938+00
d62011f9-a9c5-4720-adaf-d2ebfceac93d	49978298-e8a1-43ee-9d2d-a3f4adddbcfb	019f194f-b32d-7322-1603-70ef7d762826	30fec261-8de1-4058-8ece-468b3f8cb0f8	silver lace border	3029	roll	1.000	45.00	40.00	33.00	14.85	0.00	59.85	2026-06-30 16:41:07.169011+00
ed7c48c6-fcfc-432b-bf33-7d3c67aece82	642504e8-307f-4ed9-be80-a7f6574aef74	019f194f-b32d-7322-1603-70ef7d762826	30fec261-8de1-4058-8ece-468b3f8cb0f8	silver lace border	3029	roll	1.000	45.00	40.00	33.00	14.85	0.00	59.85	2026-06-30 16:46:52.737043+00
125d821b-cb77-475a-8b2e-60dc068fcc8c	7a635685-24b1-4c43-9051-23a125a2c8de	019f194f-b32d-7322-1603-70ef7d762826	30fec261-8de1-4058-8ece-468b3f8cb0f8	silver lace border	3029	roll	1.000	45.00	40.00	33.00	14.85	0.00	59.85	2026-06-30 16:49:26.386704+00
da029101-bc55-48e0-8827-566d4b86e8ea	29682ffb-4fc8-4999-a571-21d4eaabf099	019f194f-b32d-7322-1603-70ef7d762826	30fec261-8de1-4058-8ece-468b3f8cb0f8	silver lace border	3029	roll	1.000	45.00	40.00	33.00	14.85	0.00	59.85	2026-06-30 16:52:26.61312+00
8cdb2869-e5db-4dde-9798-818cefc9fa54	9c85de4f-40e2-475f-bfa6-58a30fc638d2	019f194f-b32d-7322-1603-70ef7d762826	30fec261-8de1-4058-8ece-468b3f8cb0f8	silver lace border	3029	roll	1.000	45.00	40.00	33.00	14.85	0.00	59.85	2026-06-30 16:57:29.787496+00
811d7a4d-84fc-428b-acc4-21a02468cbd5	ff8a9dee-ce23-4e54-ba9a-72e0cc9087ac	019f199a-3a4e-7add-24a3-55605cb81fcd	fbc4137d-6e53-4a02-99a1-0b101093e00a	gold lace border	9956	mtr	1.000	44.00	40.00	6.00	2.64	0.00	46.64	2026-06-30 18:24:45.570688+00
a38bed00-a910-4e54-ac7d-8d4538ed0398	d821af2c-3133-4a38-96f0-55bed1abe725	019f199a-3a4e-7add-24a3-55605cb81fcd	fbc4137d-6e53-4a02-99a1-0b101093e00a	gold lace border	9956	mtr	3.000	44.00	40.00	6.00	7.92	0.00	139.92	2026-06-30 18:47:22.523138+00
f951c0fd-4521-4167-ac0a-ded0a1d30e45	619613d3-6387-4e9c-9455-425cc9e4804b	019f13c6-d7f4-7716-a073-809189390517	6db44d1d-2041-4373-b0e2-bb77ec65b68a	Red thread T01	1221	bundle	7.000	12.00	10.00	10.00	8.40	0.00	92.40	2026-06-30 19:15:12.177723+00
6c464e59-7907-4256-863b-9302b83a68e3	8cd1415c-b01a-4606-8bac-59ff8a97c5f3	019f0872-7e4a-7efe-75ef-27d1fe58fa7f	be7e175f-de8c-4884-99af-149ab7dcc82a	Gold stones T01	3292	pkt	7.000	12.00	10.00	9.00	7.56	0.00	91.56	2026-06-30 19:28:31.065749+00
01b046ec-c68b-4f38-81e7-5a065ded0b8a	6f89ebfc-0e1e-4258-9c73-011532c3fe8e	019f199a-3a4e-7add-24a3-55605cb81fcd	fbc4137d-6e53-4a02-99a1-0b101093e00a	gold lace border	9956	mtr	7.000	44.00	40.00	6.00	18.48	0.00	326.48	2026-06-30 19:32:48.609796+00
a9c4b069-2e70-4ab8-92c4-2429f38d69fb	cfa68a02-eca3-400a-affa-a3ccc99f3c08	019f194f-b32d-7322-1603-70ef7d762826	30fec261-8de1-4058-8ece-468b3f8cb0f8	silver lace border	3029	roll	4.000	45.00	40.00	33.00	59.40	0.00	239.40	2026-07-04 07:56:04.455557+00
9add5d28-10e5-410a-9736-9b88a2081a55	cfa68a02-eca3-400a-affa-a3ccc99f3c08	019f0872-7e4a-7efe-75ef-27d1fe58fa7f	be7e175f-de8c-4884-99af-149ab7dcc82a	Gold stones T01	3292	pkt	3.000	12.00	10.00	9.00	3.24	0.00	39.24	2026-07-04 07:56:04.455557+00
67f1e8b9-8e1a-4de3-a3e1-24a901d897a2	cfa68a02-eca3-400a-affa-a3ccc99f3c08	019f199a-3a4e-7add-24a3-55605cb81fcd	fbc4137d-6e53-4a02-99a1-0b101093e00a	gold lace border	9956	mtr	3.000	44.00	40.00	6.00	7.92	0.00	139.92	2026-07-04 07:56:04.455557+00
4ce0948e-793b-4cf9-bf0b-e956d0c546fc	467ea02e-42b3-44fe-9379-9dada90ba313	019f194f-b32d-7322-1603-70ef7d762826	30fec261-8de1-4058-8ece-468b3f8cb0f8	silver lace border	3029	roll	4.000	45.00	40.00	33.00	59.40	0.00	239.40	2026-07-04 10:21:43.896255+00
7811c06b-4059-4e0a-b827-593f7925cec9	467ea02e-42b3-44fe-9379-9dada90ba313	019f0872-7e4a-7efe-75ef-27d1fe58fa7f	be7e175f-de8c-4884-99af-149ab7dcc82a	Gold stones T01	3292	pkt	4.000	12.00	10.00	9.00	4.32	0.00	52.32	2026-07-04 10:21:43.896255+00
1eb86311-5476-4633-b0de-923af85fbb04	467ea02e-42b3-44fe-9379-9dada90ba313	019f199a-3a4e-7add-24a3-55605cb81fcd	fbc4137d-6e53-4a02-99a1-0b101093e00a	gold lace border	9956	mtr	4.000	44.00	40.00	6.00	10.56	0.00	186.56	2026-07-04 10:21:43.896255+00
f8f1cd09-7b25-4950-93ff-a97962c3804f	56676f9f-64bb-420f-b000-0a446202360c	019f194f-b32d-7322-1603-70ef7d762826	30fec261-8de1-4058-8ece-468b3f8cb0f8	silver lace border	3029	roll	5.000	45.00	40.00	33.00	74.25	0.00	299.25	2026-07-06 14:33:16.853903+00
1e7e9025-3dc4-46b9-92ec-1d20a4c604df	56676f9f-64bb-420f-b000-0a446202360c	019f199a-3a4e-7add-24a3-55605cb81fcd	fbc4137d-6e53-4a02-99a1-0b101093e00a	gold lace border	9956	mtr	4.000	44.00	40.00	6.00	10.56	0.00	186.56	2026-07-06 14:33:16.853903+00
ad88d001-aaf1-48ab-8fcc-95898231173b	56676f9f-64bb-420f-b000-0a446202360c	019f13c6-d7f4-7716-a073-809189390517	6db44d1d-2041-4373-b0e2-bb77ec65b68a	Red thread T01	1221	bundle	4.000	12.00	10.00	10.00	4.80	0.00	52.80	2026-07-06 14:33:16.853903+00
83060ed3-1d6b-4187-bbc8-a64f1ff35cfd	58f4b302-ce72-476a-a2e6-d0933e4b8bfd	019f37dc-c782-775c-9a47-55c139b7f5f5	3ca6821b-5e6b-49be-9af6-adca87cf197f	left footer	3392	pcs	3.000	5000.00	3000.00	30.00	4500.00	0.00	19500.00	2026-07-06 14:43:49.472044+00
12317863-3fe9-47aa-a25f-c9b677a2aa3a	03d664db-f4d9-4f2c-a5d5-44edbcd93b98	019f3833-e982-7976-0867-1ff6efaa2223	31829f8a-be0a-4fc1-840d-d7aaf308a922	Orange Color B01	3392	mtr	3.000	52.00	50.00	16.00	24.96	0.00	180.96	2026-07-06 16:32:26.314539+00
67b00652-5e40-4d00-b75a-f5e560e430dd	03d664db-f4d9-4f2c-a5d5-44edbcd93b98	019f3840-b80f-788e-d21f-57b23086d62a	88bb61ba-81d6-4127-bbd0-ec5061ed4a7a	Orange color B02	9928	mtr	3.000	52.00	50.00	3.00	4.68	0.00	160.68	2026-07-06 16:32:26.314539+00
60fcba29-2b2a-446a-8123-12c77066517d	bdea4861-829c-4917-a519-d27dbf2766e1	019f37dc-c782-775c-9a47-55c139b7f5f5	3ca6821b-5e6b-49be-9af6-adca87cf197f	left footer	3392	pcs	3.000	4000.00	3000.00	30.00	3600.00	0.00	15600.00	2026-07-07 11:24:32.082028+00
c9268564-4c67-47ae-bf6b-42eb488bec8e	46202432-e47b-4f33-93b7-3d059191dfd9	019f37dc-c782-775c-9a47-55c139b7f5f5	3ca6821b-5e6b-49be-9af6-adca87cf197f	left footer	3392	pcs	19.000	4000.00	3000.00	30.00	22800.00	0.00	98800.00	2026-07-08 13:20:17.64762+00
bbd738eb-b5ef-43a5-8698-b5a28417704b	1a2ea9dc-5da6-4f7e-b3ee-dddb6b367e21	019f3840-b80f-788e-d21f-57b23086d62a	88bb61ba-81d6-4127-bbd0-ec5061ed4a7a	Orange color B02	9928	mtr	16.000	52.00	50.00	3.00	24.96	0.00	856.96	2026-07-08 13:28:10.768729+00
\.


--
-- Data for Name: invoice_returns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_returns (id, invoice_id, invoice_item_id, product_id, batch_id, qty_returned, refund_amount, restock_qty, reason, created_at) FROM stdin;
\.


--
-- Data for Name: invoice_sequences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_sequences (id, user_id, year, prefix, last_number, updated_at) FROM stdin;
34d55bec-0633-489b-ba72-3df15c53e814	e165e33e-0b13-4db9-93bb-79858a78a74a	2026	INV	1	2026-06-30 15:51:54.183235+00
b1889428-0147-4c63-a65b-7f305ceb5d9b	019f085a-3064-70f4-7264-abe1b57813df	2026	INV	25	2026-07-08 13:28:10.758532+00
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoices (id, user_id, invoice_number, customer_id, customer_name_snapshot, customer_phone_snapshot, customer_gstin_snapshot, subtotal, discount_amount, total_gst, round_off, grand_total, amount_paid, balance_due, invoice_status, payment_status, notes, billed_at, created_at, updated_at) FROM stdin;
677e4ef1-1a26-49ff-bab6-c5413b48643e	019f085a-3064-70f4-7264-abe1b57813df	INV-2026-000001	\N	-- Walk-in Customer (No Credit) --	\N	\N	24.00	0.00	2.28	-0.28	26.00	26.00	0.00	completed	paid	\N	2026-06-30 12:50:43+00	2026-06-30 12:50:43.780025+00	2026-06-30 12:50:43.780025+00
3331828c-d612-4d58-910f-9e11af9cb29e	019f085a-3064-70f4-7264-abe1b57813df	INV-2026-000002	\N	-- Walk-in Customer (No Credit) --	\N	\N	24.00	0.00	2.28	-0.28	26.00	26.00	0.00	completed	paid	\N	2026-06-30 15:07:23+00	2026-06-30 15:07:23.920159+00	2026-06-30 15:07:23.920159+00
a19b37bb-e673-45db-b13a-0a072c209404	019f085a-3064-70f4-7264-abe1b57813df	INV-2026-000003	\N	-- Walk-in Customer (No Credit) --	\N	\N	24.00	0.00	2.28	-0.28	26.00	26.00	0.00	completed	paid	\N	2026-06-30 15:14:22+00	2026-06-30 15:14:22.203415+00	2026-06-30 15:14:22.203415+00
ea3eb01c-efe0-4dbb-a054-70bd5118bf7b	e165e33e-0b13-4db9-93bb-79858a78a74a	INV-2026-000001	\N	Test Customer	\N	\N	583.00	0.00	69.96	0.04	653.00	700.00	0.00	completed	paid	\N	2026-06-30 15:51:54+00	2026-06-30 15:51:54.198382+00	2026-06-30 15:51:54.198382+00
2682423e-1c82-4b57-97c0-2681aadf9a00	019f085a-3064-70f4-7264-abe1b57813df	INV-2026-000004	\N	-- Walk-in Customer (No Credit) --	\N	\N	48.00	0.00	4.56	0.44	53.00	53.00	0.00	completed	paid	\N	2026-06-30 16:00:55+00	2026-06-30 16:00:55.378241+00	2026-06-30 16:00:55.378241+00
d101dd54-f858-43ac-914b-3b96f36a55e9	019f085a-3064-70f4-7264-abe1b57813df	INV-2026-000005	\N	-- Walk-in Customer (No Credit) --	\N	\N	12.00	0.00	1.08	-0.08	13.00	13.00	0.00	completed	paid	\N	2026-06-30 16:02:27+00	2026-06-30 16:02:27.085409+00	2026-06-30 16:02:27.085409+00
7e36c091-9ae1-49e8-aa45-cbe47b0a1ca7	019f085a-3064-70f4-7264-abe1b57813df	INV-2026-000006	\N	-- Walk-in Customer (No Credit) --	\N	\N	45.00	0.00	14.85	0.15	60.00	60.00	0.00	completed	paid	\N	2026-06-30 16:18:09+00	2026-06-30 16:18:09.345991+00	2026-06-30 16:18:09.345991+00
8f3e532d-2b71-4b6a-a5e9-b25c6c1a2fbe	019f085a-3064-70f4-7264-abe1b57813df	INV-2026-000007	\N	-- Walk-in Customer (No Credit) --	\N	\N	45.00	0.00	14.85	0.15	60.00	60.00	0.00	completed	paid	\N	2026-06-30 16:35:08+00	2026-06-30 16:35:08.894938+00	2026-06-30 16:35:08.894938+00
49978298-e8a1-43ee-9d2d-a3f4adddbcfb	019f085a-3064-70f4-7264-abe1b57813df	INV-2026-000008	\N	-- Walk-in Customer (No Credit) --	\N	\N	45.00	0.00	14.85	0.15	60.00	59.00	1.00	completed	partial	\N	2026-06-30 16:41:07+00	2026-06-30 16:41:07.169011+00	2026-06-30 16:41:07.169011+00
642504e8-307f-4ed9-be80-a7f6574aef74	019f085a-3064-70f4-7264-abe1b57813df	INV-2026-000009	\N	-- Walk-in Customer (No Credit) --	\N	\N	45.00	0.00	14.85	0.15	60.00	59.00	1.00	completed	partial	\N	2026-06-30 16:46:52+00	2026-06-30 16:46:52.737043+00	2026-06-30 16:46:52.737043+00
7a635685-24b1-4c43-9051-23a125a2c8de	019f085a-3064-70f4-7264-abe1b57813df	INV-2026-000010	\N	-- Walk-in Customer (No Credit) --	\N	\N	45.00	0.00	14.85	0.15	60.00	59.00	1.00	completed	partial	\N	2026-06-30 16:49:26+00	2026-06-30 16:49:26.386704+00	2026-06-30 16:49:26.386704+00
29682ffb-4fc8-4999-a571-21d4eaabf099	019f085a-3064-70f4-7264-abe1b57813df	INV-2026-000011	\N	-- Walk-in Customer (No Credit) --	\N	\N	45.00	0.00	14.85	0.15	60.00	60.00	0.00	completed	paid	\N	2026-06-30 16:52:26+00	2026-06-30 16:52:26.61312+00	2026-06-30 16:52:26.61312+00
9c85de4f-40e2-475f-bfa6-58a30fc638d2	019f085a-3064-70f4-7264-abe1b57813df	INV-2026-000012	\N	-- Walk-in Customer (No Credit) --	\N	\N	45.00	0.00	14.85	0.15	60.00	59.00	1.00	completed	partial	\N	2026-06-30 16:57:29+00	2026-06-30 16:57:29.787496+00	2026-06-30 16:57:29.787496+00
ff8a9dee-ce23-4e54-ba9a-72e0cc9087ac	019f085a-3064-70f4-7264-abe1b57813df	INV-2026-000013	\N	-- Walk-in Customer (No Credit) --	\N	\N	44.00	0.00	2.64	0.36	47.00	47.00	0.00	completed	paid	\N	2026-06-30 18:24:45+00	2026-06-30 18:24:45.570688+00	2026-06-30 18:24:45.570688+00
d821af2c-3133-4a38-96f0-55bed1abe725	019f085a-3064-70f4-7264-abe1b57813df	INV-2026-000014	\N	aishwarya	7530019108	\N	132.00	0.00	7.92	0.08	140.00	48.00	92.00	completed	partial	\N	2026-06-30 18:47:22+00	2026-06-30 18:47:22.523138+00	2026-06-30 18:47:22.523138+00
619613d3-6387-4e9c-9455-425cc9e4804b	019f085a-3064-70f4-7264-abe1b57813df	INV-2026-000015	\N	aishwarya	7530019108	\N	84.00	0.00	8.40	-0.40	92.00	40.00	52.00	completed	partial	\N	2026-06-30 19:15:12+00	2026-06-30 19:15:12.177723+00	2026-06-30 19:15:12.177723+00
8cd1415c-b01a-4606-8bac-59ff8a97c5f3	019f085a-3064-70f4-7264-abe1b57813df	INV-2026-000016	\N	surya	9042357007	\N	84.00	0.00	7.56	0.44	92.00	44.00	48.00	completed	partial	\N	2026-06-30 19:28:31+00	2026-06-30 19:28:31.065749+00	2026-06-30 19:28:31.065749+00
6f89ebfc-0e1e-4258-9c73-011532c3fe8e	019f085a-3064-70f4-7264-abe1b57813df	INV-2026-000017	1048e40b-e9f5-4890-b3ee-9d5bedf2b7a1	Angayarkanni S	09884983412	\N	308.00	0.00	18.48	-0.48	326.00	198.00	128.00	deleted	partial	\N	2026-06-30 19:32:48+00	2026-06-30 19:32:48.609796+00	2026-07-01 08:41:08.928365+00
cfa68a02-eca3-400a-affa-a3ccc99f3c08	019f085a-3064-70f4-7264-abe1b57813df	INV-2026-000018	8d24bfca-aa8e-49e3-9146-b2a358bbef94	surya	9042357007	\N	348.00	0.00	70.56	0.44	419.00	200.00	219.00	completed	partial	\N	2026-07-04 07:56:04+00	2026-07-04 07:56:04.455557+00	2026-07-04 07:56:04.455557+00
467ea02e-42b3-44fe-9379-9dada90ba313	019f085a-3064-70f4-7264-abe1b57813df	INV-2026-000019	\N	Walk-in	\N	\N	404.00	0.00	74.28	-0.28	478.00	200.00	278.00	completed	partial	\N	2026-07-04 10:21:43+00	2026-07-04 10:21:43.896255+00	2026-07-04 10:21:43.896255+00
56676f9f-64bb-420f-b000-0a446202360c	019f085a-3064-70f4-7264-abe1b57813df	INV-2026-000020	217ab7ba-8c32-45c8-9659-2126e1fc0c14	aishwarya	7530019108	\N	449.00	30.00	89.61	0.39	509.00	250.00	259.00	completed	partial	\N	2026-07-06 14:33:16+00	2026-07-06 14:33:16.853903+00	2026-07-06 14:33:16.853903+00
58f4b302-ce72-476a-a2e6-d0933e4b8bfd	019f085a-3064-70f4-7264-abe1b57813df	INV-2026-000021	289f7c7d-3ec2-4930-81ce-417d3db23358	suba	9092926626	\N	15000.00	1000.00	4500.00	0.00	18500.00	15000.00	3500.00	completed	partial	\N	2026-07-06 14:43:49+00	2026-07-06 14:43:49.472044+00	2026-07-06 14:43:49.472044+00
03d664db-f4d9-4f2c-a5d5-44edbcd93b98	019f085a-3064-70f4-7264-abe1b57813df	INV-2026-000022	1048e40b-e9f5-4890-b3ee-9d5bedf2b7a1	Angayarkanni S	09884983412	\N	312.00	20.00	29.64	0.36	322.00	200.00	122.00	completed	partial	\N	2026-07-06 16:32:26+00	2026-07-06 16:32:26.314539+00	2026-07-06 16:32:26.314539+00
bdea4861-829c-4917-a519-d27dbf2766e1	019f085a-3064-70f4-7264-abe1b57813df	INV-2026-000023	8d24bfca-aa8e-49e3-9146-b2a358bbef94	surya	9042357007	\N	12000.00	0.00	3600.00	0.00	15600.00	10000.00	5600.00	completed	partial	\N	2026-07-07 11:24:32+00	2026-07-07 11:24:32.082028+00	2026-07-07 11:24:32.082028+00
46202432-e47b-4f33-93b7-3d059191dfd9	019f085a-3064-70f4-7264-abe1b57813df	INV-2026-000024	\N	Walk-in	\N	\N	76000.00	0.00	22800.00	0.00	98800.00	50000.00	48800.00	completed	partial	\N	2026-07-08 13:20:17+00	2026-07-08 13:20:17.64762+00	2026-07-08 13:20:17.64762+00
1a2ea9dc-5da6-4f7e-b3ee-dddb6b367e21	019f085a-3064-70f4-7264-abe1b57813df	INV-2026-000025	8d24bfca-aa8e-49e3-9146-b2a358bbef94	surya	9042357007	\N	832.00	0.00	24.96	0.04	857.00	490.00	367.00	completed	partial	\N	2026-07-08 13:28:10+00	2026-07-08 13:28:10.768729+00	2026-07-08 13:28:10.768729+00
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.migrations (id, filename, executed_at) FROM stdin;
2	Auth/001_users_schema.sql	2026-05-30 07:24:22.333864+00
3	Auth/002_password_resets.sql	2026-05-30 07:24:22.395447+00
4	Products/003_categories_schema.sql	2026-05-30 07:24:22.444132+00
5	Products/004_subcategories_schema.sql	2026-05-30 07:24:22.496848+00
6	Products/005_products_schema.sql	2026-05-30 07:24:22.566319+00
7	Dashboard/006_dashboard_schema.sql	2026-06-01 10:45:35.774699+00
8	000_functions.sql	2026-06-02 08:54:15.34091+00
9	Products/006_products_alert_columns.sql	2026-06-07 12:40:11.465706+00
10	Dashboard/007_add_vendor_name_to_batches.sql	2026-06-08 17:51:02.442029+00
11	Dashboard/007_dashboard_schema.sql	2026-06-14 17:16:51.148013+00
12	Dashboard/008_add_vendor_name_to_batches.sql	2026-06-14 17:16:51.153052+00
13	Vendor/009_vendors.sql	2026-06-14 17:17:48.619662+00
14	Vendor/010_add_gst_rate_to_purchase_items.sql	2026-06-20 20:21:03.540611+00
15	Vendor/011_vendor_payments.sql	2026-06-22 17:25:37.085828+00
16	Billing/012_billing_schema.sql	2026-06-26 06:36:12.511931+00
17	Customer/013_customer_credit_schema.sql	2026-06-30 19:05:28.816389+00
18	Products/014_product_daily_sales.sql	2026-07-07 09:55:27.136539+00
19	Products/015_add_original_quantity.sql	2026-07-07 09:55:27.149406+00
20	Settings/016_backup_schema.sql	2026-07-08 17:45:02.536901+00
\.


--
-- Data for Name: password_resets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.password_resets (id, user_id, token, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: payment_receipt_sequences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_receipt_sequences (id, user_id, year, prefix, last_number, updated_at) FROM stdin;
c0efc358-f27d-4465-8589-14d66a2482f5	019f085a-3064-70f4-7264-abe1b57813df	2026	PAY	4	2026-07-04 07:52:23.86659+00
\.


--
-- Data for Name: payment_receipts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_receipts (id, user_id, customer_id, ledger_id, receipt_number, amount, notes, created_at) FROM stdin;
7dc39dd5-09b3-4953-8b3a-2c699d0f4c27	019f085a-3064-70f4-7264-abe1b57813df	1048e40b-e9f5-4890-b3ee-9d5bedf2b7a1	d7ad9ae7-3db1-48cd-9110-0ac444581356	PAY-2026-000001	100.00	partial payment	2026-06-30 19:33:18.719549+00
0f6dcdbb-ca25-436d-a668-d857b61cc4b0	019f085a-3064-70f4-7264-abe1b57813df	1048e40b-e9f5-4890-b3ee-9d5bedf2b7a1	0dfcc32c-e402-4242-b34f-6c0bd1a7227f	PAY-2026-000002	28.00	cleared	2026-07-01 08:46:18.323577+00
0689daa9-a52a-4013-8595-2e9562142952	019f085a-3064-70f4-7264-abe1b57813df	8d24bfca-aa8e-49e3-9146-b2a358bbef94	07277ff9-dbdc-4308-8c42-4a76f62ec69f	PAY-2026-000003	1000.00	partial	2026-07-01 08:54:25.784998+00
e0536c08-af10-4ca7-8d0e-ca2dc391d901	019f085a-3064-70f4-7264-abe1b57813df	8d24bfca-aa8e-49e3-9146-b2a358bbef94	3cc02d17-65e0-4034-9bf4-544dfdaf524d	PAY-2026-000004	1000.00	done	2026-07-04 07:52:23.86659+00
\.


--
-- Data for Name: product_daily_sales; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_daily_sales (id, user_id, product_id, sale_date, quantity, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, user_id, category_id, subcategory_id, name, unit, hsn_code, gst_rate, created_at, updated_at, daily_sales, lead_time, emergency_stock, rop, alert_triggered) FROM stdin;
c1111111-2222-3333-4444-555555555501	e165e33e-0b13-4db9-93bb-79858a78a74a	a1111111-2222-3333-4444-555555555551	b1111111-2222-3333-4444-555555555551	Premium Cotton Shirt	pcs	HSN12345	18.00	2026-06-26 12:24:37.847675+00	2026-06-26 12:24:37.847675+00	0	0	0	0	f
c1111111-2222-3333-4444-555555555502	e165e33e-0b13-4db9-93bb-79858a78a74a	a1111111-2222-3333-4444-555555555551	b1111111-2222-3333-4444-555555555551	Oxford Button Down Shirt	pcs	HSN12346	18.00	2026-06-26 12:24:37.850846+00	2026-06-26 12:24:37.850846+00	0	0	0	0	f
c1111111-2222-3333-4444-555555555503	e165e33e-0b13-4db9-93bb-79858a78a74a	a1111111-2222-3333-4444-555555555552	b1111111-2222-3333-4444-555555555552	Classic White Sneakers	pairs	HSN54321	12.00	2026-06-26 12:24:37.855632+00	2026-06-26 12:24:37.855632+00	0	0	0	0	f
c1111111-2222-3333-4444-555555555504	e165e33e-0b13-4db9-93bb-79858a78a74a	a1111111-2222-3333-4444-555555555553	b1111111-2222-3333-4444-555555555553	Pro Phone 15	pcs	HSN98765	18.00	2026-06-26 12:24:37.861389+00	2026-06-26 12:24:37.861389+00	0	0	0	0	f
c1111111-2222-3333-4444-555555555505	e165e33e-0b13-4db9-93bb-79858a78a74a	a1111111-2222-3333-4444-555555555554	b1111111-2222-3333-4444-555555555554	Non-Stick Frying Pan	pcs	HSN45678	12.00	2026-06-26 12:24:37.867022+00	2026-06-26 12:24:37.867022+00	0	0	0	0	f
c1111111-2222-3333-4444-555555555506	e165e33e-0b13-4db9-93bb-79858a78a74a	a1111111-2222-3333-4444-555555555555	b1111111-2222-3333-4444-555555555555	The Great Adventure Novel	pcs	HSN78901	5.00	2026-06-26 12:24:37.872086+00	2026-06-26 12:24:37.872086+00	0	0	0	0	f
019f0872-7e4a-7efe-75ef-27d1fe58fa7f	019f085a-3064-70f4-7264-abe1b57813df	019f0870-1242-7223-6725-3cab29b2a86b	019f0870-33ab-7378-4fd1-907aaeb8cabd	Gold stones T01	pkt	3292	9.00	2026-06-27 09:39:08.999588+00	2026-06-27 09:39:08.999588+00	0	0	0	0	f
019f13c6-d7f4-7716-a073-809189390517	019f085a-3064-70f4-7264-abe1b57813df	019f0871-5e20-7e31-d6d1-5b43508013e7	019f0871-9cef-7c24-a70a-e3d11fba6376	Red thread T01	bundle	1221	10.00	2026-06-29 14:27:06.350601+00	2026-06-30 09:12:09.503529+00	3	5	5	20	t
019f194f-b32d-7322-1603-70ef7d762826	019f085a-3064-70f4-7264-abe1b57813df	019f194f-182d-78ee-6bbe-b2f8058006bf	\N	silver lace border	roll	3029	33.00	2026-06-30 16:14:41.450649+00	2026-06-30 16:14:41.450649+00	0	0	0	0	f
019f199a-3a4e-7add-24a3-55605cb81fcd	019f085a-3064-70f4-7264-abe1b57813df	019f194f-182d-78ee-6bbe-b2f8058006bf	\N	gold lace border	mtr	9956	6.00	2026-06-30 17:36:05.707259+00	2026-06-30 17:36:05.707259+00	0	0	0	0	f
019f3833-e982-7976-0867-1ff6efaa2223	019f085a-3064-70f4-7264-abe1b57813df	019f3832-5804-782a-700f-e1ec52a0d1a9	019f3832-8d4d-7d35-a0f9-e3f3050265ee	Orange Color B01	mtr	3392	16.00	2026-07-06 16:12:34.048329+00	2026-07-06 16:12:34.048329+00	0	0	0	0	f
019f384d-6bd2-7b21-747a-543903f29e80	019f085a-3064-70f4-7264-abe1b57813df	019f3832-5804-782a-700f-e1ec52a0d1a9	019f384c-ef07-7fd7-c1a8-5cd505f45962	Red color B01	mtr	3302	8.00	2026-07-06 16:40:25.808974+00	2026-07-06 16:40:25.808974+00	0	0	0	0	f
019f37dc-c782-775c-9a47-55c139b7f5f5	019f085a-3064-70f4-7264-abe1b57813df	019f37dc-3278-7256-4800-d2a5c84ae44d	\N	left footer	pcs	3392	30.00	2026-07-06 14:37:23.71198+00	2026-07-08 13:18:51.397623+00	1	5	0	5	f
019f3840-b80f-788e-d21f-57b23086d62a	019f085a-3064-70f4-7264-abe1b57813df	019f3832-5804-782a-700f-e1ec52a0d1a9	019f3832-8d4d-7d35-a0f9-e3f3050265ee	Orange color B02	mtr	9928	3.00	2026-07-06 16:26:33.35747+00	2026-07-08 13:27:24.989651+00	3	3	2	11	f
\.


--
-- Data for Name: purchases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchases (id, user_id, vendor_id, total_amount, paid_amount, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stock_list; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_list (id, user_id, product_id, quantity, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_movements (id, user_id, batch_id, product_id, reference_type, reference_id, movement_type, qty, created_at) FROM stdin;
6c868647-7f50-4625-9309-bb2eb8598acb	019f085a-3064-70f4-7264-abe1b57813df	6db44d1d-2041-4373-b0e2-bb77ec65b68a	019f13c6-d7f4-7716-a073-809189390517	SALE	677e4ef1-1a26-49ff-bab6-c5413b48643e	OUT	1.000	2026-06-30 12:50:43.780025+00
fbe121b2-8b1f-46b0-a974-c34342fd68ba	019f085a-3064-70f4-7264-abe1b57813df	be7e175f-de8c-4884-99af-149ab7dcc82a	019f0872-7e4a-7efe-75ef-27d1fe58fa7f	SALE	677e4ef1-1a26-49ff-bab6-c5413b48643e	OUT	1.000	2026-06-30 12:50:43.780025+00
2508c185-d660-4a12-8e0e-613d4166fe11	019f085a-3064-70f4-7264-abe1b57813df	6db44d1d-2041-4373-b0e2-bb77ec65b68a	019f13c6-d7f4-7716-a073-809189390517	SALE	3331828c-d612-4d58-910f-9e11af9cb29e	OUT	1.000	2026-06-30 15:07:23.920159+00
e677aab4-03d3-47c9-94ad-a0007f399de9	019f085a-3064-70f4-7264-abe1b57813df	be7e175f-de8c-4884-99af-149ab7dcc82a	019f0872-7e4a-7efe-75ef-27d1fe58fa7f	SALE	3331828c-d612-4d58-910f-9e11af9cb29e	OUT	1.000	2026-06-30 15:07:23.920159+00
f8624aac-c3e9-4457-a2f2-b209e816489c	019f085a-3064-70f4-7264-abe1b57813df	6db44d1d-2041-4373-b0e2-bb77ec65b68a	019f13c6-d7f4-7716-a073-809189390517	SALE	a19b37bb-e673-45db-b13a-0a072c209404	OUT	1.000	2026-06-30 15:14:22.203415+00
89e91fe4-baaf-40bb-9da2-cd4ed365e711	019f085a-3064-70f4-7264-abe1b57813df	be7e175f-de8c-4884-99af-149ab7dcc82a	019f0872-7e4a-7efe-75ef-27d1fe58fa7f	SALE	a19b37bb-e673-45db-b13a-0a072c209404	OUT	1.000	2026-06-30 15:14:22.203415+00
a239bd01-0bc5-46cc-80f6-8c5b9e9c3d23	e165e33e-0b13-4db9-93bb-79858a78a74a	4307a5bb-e98d-4fff-a873-ce9b0c434b06	c1111111-2222-3333-4444-555555555503	SALE	ea3eb01c-efe0-4dbb-a054-70bd5118bf7b	OUT	1.000	2026-06-30 15:51:54.198382+00
c2a4754d-0a96-4ca7-b7ac-97f02ab5e612	019f085a-3064-70f4-7264-abe1b57813df	6db44d1d-2041-4373-b0e2-bb77ec65b68a	019f13c6-d7f4-7716-a073-809189390517	SALE	2682423e-1c82-4b57-97c0-2681aadf9a00	OUT	2.000	2026-06-30 16:00:55.378241+00
349140fd-9e99-4b7f-98aa-858ca08a4d15	019f085a-3064-70f4-7264-abe1b57813df	be7e175f-de8c-4884-99af-149ab7dcc82a	019f0872-7e4a-7efe-75ef-27d1fe58fa7f	SALE	2682423e-1c82-4b57-97c0-2681aadf9a00	OUT	2.000	2026-06-30 16:00:55.378241+00
4979d1ec-9e2b-40e7-bad7-d7b1e32d6fde	019f085a-3064-70f4-7264-abe1b57813df	be7e175f-de8c-4884-99af-149ab7dcc82a	019f0872-7e4a-7efe-75ef-27d1fe58fa7f	SALE	d101dd54-f858-43ac-914b-3b96f36a55e9	OUT	1.000	2026-06-30 16:02:27.085409+00
6f1f4ebb-48eb-4fba-a19b-96089af42e09	019f085a-3064-70f4-7264-abe1b57813df	30fec261-8de1-4058-8ece-468b3f8cb0f8	019f194f-b32d-7322-1603-70ef7d762826	SALE	7e36c091-9ae1-49e8-aa45-cbe47b0a1ca7	OUT	1.000	2026-06-30 16:18:09.345991+00
d17810da-6292-4fb4-8198-bf58c38824a2	019f085a-3064-70f4-7264-abe1b57813df	30fec261-8de1-4058-8ece-468b3f8cb0f8	019f194f-b32d-7322-1603-70ef7d762826	SALE	8f3e532d-2b71-4b6a-a5e9-b25c6c1a2fbe	OUT	1.000	2026-06-30 16:35:08.894938+00
543eb6f9-3187-4159-8008-cc4031ace981	019f085a-3064-70f4-7264-abe1b57813df	30fec261-8de1-4058-8ece-468b3f8cb0f8	019f194f-b32d-7322-1603-70ef7d762826	SALE	49978298-e8a1-43ee-9d2d-a3f4adddbcfb	OUT	1.000	2026-06-30 16:41:07.169011+00
8545afec-5f3e-4650-9751-07e0c4291e17	019f085a-3064-70f4-7264-abe1b57813df	30fec261-8de1-4058-8ece-468b3f8cb0f8	019f194f-b32d-7322-1603-70ef7d762826	SALE	642504e8-307f-4ed9-be80-a7f6574aef74	OUT	1.000	2026-06-30 16:46:52.737043+00
eb6e44d7-d90c-49b3-b371-0e14d8586698	019f085a-3064-70f4-7264-abe1b57813df	30fec261-8de1-4058-8ece-468b3f8cb0f8	019f194f-b32d-7322-1603-70ef7d762826	SALE	7a635685-24b1-4c43-9051-23a125a2c8de	OUT	1.000	2026-06-30 16:49:26.386704+00
5e8f6db9-3025-4007-8aa8-2f20ac4c45f6	019f085a-3064-70f4-7264-abe1b57813df	30fec261-8de1-4058-8ece-468b3f8cb0f8	019f194f-b32d-7322-1603-70ef7d762826	SALE	29682ffb-4fc8-4999-a571-21d4eaabf099	OUT	1.000	2026-06-30 16:52:26.61312+00
396af895-e493-462d-82e0-be859b41ad47	019f085a-3064-70f4-7264-abe1b57813df	30fec261-8de1-4058-8ece-468b3f8cb0f8	019f194f-b32d-7322-1603-70ef7d762826	SALE	9c85de4f-40e2-475f-bfa6-58a30fc638d2	OUT	1.000	2026-06-30 16:57:29.787496+00
d8a70868-0848-4568-9848-ded189b2e537	019f085a-3064-70f4-7264-abe1b57813df	fbc4137d-6e53-4a02-99a1-0b101093e00a	019f199a-3a4e-7add-24a3-55605cb81fcd	SALE	ff8a9dee-ce23-4e54-ba9a-72e0cc9087ac	OUT	1.000	2026-06-30 18:24:45.570688+00
57cbb366-cbb0-43f8-a697-9d05547a8dce	019f085a-3064-70f4-7264-abe1b57813df	fbc4137d-6e53-4a02-99a1-0b101093e00a	019f199a-3a4e-7add-24a3-55605cb81fcd	SALE	d821af2c-3133-4a38-96f0-55bed1abe725	OUT	3.000	2026-06-30 18:47:22.523138+00
0b2e06d3-2622-4cca-bc40-657f14a1b829	019f085a-3064-70f4-7264-abe1b57813df	6db44d1d-2041-4373-b0e2-bb77ec65b68a	019f13c6-d7f4-7716-a073-809189390517	SALE	619613d3-6387-4e9c-9455-425cc9e4804b	OUT	7.000	2026-06-30 19:15:12.177723+00
ee8c023f-7104-45e7-b3b9-cce07f669dbf	019f085a-3064-70f4-7264-abe1b57813df	be7e175f-de8c-4884-99af-149ab7dcc82a	019f0872-7e4a-7efe-75ef-27d1fe58fa7f	SALE	8cd1415c-b01a-4606-8bac-59ff8a97c5f3	OUT	7.000	2026-06-30 19:28:31.065749+00
5cc95321-2073-4969-aceb-3bab45040b00	019f085a-3064-70f4-7264-abe1b57813df	fbc4137d-6e53-4a02-99a1-0b101093e00a	019f199a-3a4e-7add-24a3-55605cb81fcd	SALE	6f89ebfc-0e1e-4258-9c73-011532c3fe8e	OUT	7.000	2026-06-30 19:32:48.609796+00
e0d55aec-09e0-43dd-9d00-d92f88342ba1	019f085a-3064-70f4-7264-abe1b57813df	30fec261-8de1-4058-8ece-468b3f8cb0f8	019f194f-b32d-7322-1603-70ef7d762826	SALE	cfa68a02-eca3-400a-affa-a3ccc99f3c08	OUT	4.000	2026-07-04 07:56:04.455557+00
75be8289-4467-45a3-a07e-790739899593	019f085a-3064-70f4-7264-abe1b57813df	be7e175f-de8c-4884-99af-149ab7dcc82a	019f0872-7e4a-7efe-75ef-27d1fe58fa7f	SALE	cfa68a02-eca3-400a-affa-a3ccc99f3c08	OUT	3.000	2026-07-04 07:56:04.455557+00
77885dbd-3033-47cb-880e-890499e60459	019f085a-3064-70f4-7264-abe1b57813df	fbc4137d-6e53-4a02-99a1-0b101093e00a	019f199a-3a4e-7add-24a3-55605cb81fcd	SALE	cfa68a02-eca3-400a-affa-a3ccc99f3c08	OUT	3.000	2026-07-04 07:56:04.455557+00
9ceae119-52e1-44f0-9cdf-b1d7bbfa8190	019f085a-3064-70f4-7264-abe1b57813df	30fec261-8de1-4058-8ece-468b3f8cb0f8	019f194f-b32d-7322-1603-70ef7d762826	SALE	467ea02e-42b3-44fe-9379-9dada90ba313	OUT	4.000	2026-07-04 10:21:43.896255+00
36d0aaf2-71ed-40ec-b9c0-1398ba0c8764	019f085a-3064-70f4-7264-abe1b57813df	be7e175f-de8c-4884-99af-149ab7dcc82a	019f0872-7e4a-7efe-75ef-27d1fe58fa7f	SALE	467ea02e-42b3-44fe-9379-9dada90ba313	OUT	4.000	2026-07-04 10:21:43.896255+00
d3a8dd1f-a288-4569-895b-e5ff6a9acb4e	019f085a-3064-70f4-7264-abe1b57813df	fbc4137d-6e53-4a02-99a1-0b101093e00a	019f199a-3a4e-7add-24a3-55605cb81fcd	SALE	467ea02e-42b3-44fe-9379-9dada90ba313	OUT	4.000	2026-07-04 10:21:43.896255+00
60463965-806a-47ff-b509-03491e922942	019f085a-3064-70f4-7264-abe1b57813df	30fec261-8de1-4058-8ece-468b3f8cb0f8	019f194f-b32d-7322-1603-70ef7d762826	SALE	56676f9f-64bb-420f-b000-0a446202360c	OUT	5.000	2026-07-06 14:33:16.853903+00
872700ce-4b2c-48a3-b221-6c85d51158ab	019f085a-3064-70f4-7264-abe1b57813df	fbc4137d-6e53-4a02-99a1-0b101093e00a	019f199a-3a4e-7add-24a3-55605cb81fcd	SALE	56676f9f-64bb-420f-b000-0a446202360c	OUT	4.000	2026-07-06 14:33:16.853903+00
5035ff99-b17e-4832-bfcd-6ed76f5117c7	019f085a-3064-70f4-7264-abe1b57813df	6db44d1d-2041-4373-b0e2-bb77ec65b68a	019f13c6-d7f4-7716-a073-809189390517	SALE	56676f9f-64bb-420f-b000-0a446202360c	OUT	4.000	2026-07-06 14:33:16.853903+00
d61b5a6a-c617-4bd5-9000-a061f01d5052	019f085a-3064-70f4-7264-abe1b57813df	3ca6821b-5e6b-49be-9af6-adca87cf197f	019f37dc-c782-775c-9a47-55c139b7f5f5	SALE	58f4b302-ce72-476a-a2e6-d0933e4b8bfd	OUT	3.000	2026-07-06 14:43:49.472044+00
788b2a29-da42-48bf-a4f9-e6bcbdad94ae	019f085a-3064-70f4-7264-abe1b57813df	31829f8a-be0a-4fc1-840d-d7aaf308a922	019f3833-e982-7976-0867-1ff6efaa2223	SALE	03d664db-f4d9-4f2c-a5d5-44edbcd93b98	OUT	3.000	2026-07-06 16:32:26.314539+00
2fa24682-a3e2-48cd-a7ad-46c28a5b260b	019f085a-3064-70f4-7264-abe1b57813df	88bb61ba-81d6-4127-bbd0-ec5061ed4a7a	019f3840-b80f-788e-d21f-57b23086d62a	SALE	03d664db-f4d9-4f2c-a5d5-44edbcd93b98	OUT	3.000	2026-07-06 16:32:26.314539+00
441dac9a-4b68-4e02-8367-a048985bbaa4	019f085a-3064-70f4-7264-abe1b57813df	3ca6821b-5e6b-49be-9af6-adca87cf197f	019f37dc-c782-775c-9a47-55c139b7f5f5	SALE	bdea4861-829c-4917-a519-d27dbf2766e1	OUT	3.000	2026-07-07 11:24:32.082028+00
9fdc55e3-9fbd-4e72-9432-3f153be1858f	019f085a-3064-70f4-7264-abe1b57813df	3ca6821b-5e6b-49be-9af6-adca87cf197f	019f37dc-c782-775c-9a47-55c139b7f5f5	SALE	46202432-e47b-4f33-93b7-3d059191dfd9	OUT	19.000	2026-07-08 13:20:17.64762+00
626fa85b-6bbb-47b0-9683-74cea43e3e4b	019f085a-3064-70f4-7264-abe1b57813df	88bb61ba-81d6-4127-bbd0-ec5061ed4a7a	019f3840-b80f-788e-d21f-57b23086d62a	SALE	1a2ea9dc-5da6-4f7e-b3ee-dddb6b367e21	OUT	16.000	2026-07-08 13:28:10.768729+00
\.


--
-- Data for Name: subcategories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subcategories (id, user_id, category_id, name, created_at) FROM stdin;
b1111111-2222-3333-4444-555555555551	e165e33e-0b13-4db9-93bb-79858a78a74a	a1111111-2222-3333-4444-555555555551	Men Shirts	2026-06-26 12:24:37.844748+00
b1111111-2222-3333-4444-555555555552	e165e33e-0b13-4db9-93bb-79858a78a74a	a1111111-2222-3333-4444-555555555552	Sneakers	2026-06-26 12:24:37.854019+00
b1111111-2222-3333-4444-555555555553	e165e33e-0b13-4db9-93bb-79858a78a74a	a1111111-2222-3333-4444-555555555553	Smartphones	2026-06-26 12:24:37.859501+00
b1111111-2222-3333-4444-555555555554	e165e33e-0b13-4db9-93bb-79858a78a74a	a1111111-2222-3333-4444-555555555554	Cookware	2026-06-26 12:24:37.865428+00
b1111111-2222-3333-4444-555555555555	e165e33e-0b13-4db9-93bb-79858a78a74a	a1111111-2222-3333-4444-555555555555	Novels	2026-06-26 12:24:37.870464+00
019f0870-33ab-7378-4fd1-907aaeb8cabd	019f085a-3064-70f4-7264-abe1b57813df	019f0870-1242-7223-6725-3cab29b2a86b	Gold Stones	2026-06-27 09:36:38.824424+00
019f0870-a080-70ab-00d6-ba86a93a21d7	019f085a-3064-70f4-7264-abe1b57813df	019f0870-1242-7223-6725-3cab29b2a86b	Silver Stones	2026-06-27 09:37:06.683429+00
019f0871-9cef-7c24-a70a-e3d11fba6376	019f085a-3064-70f4-7264-abe1b57813df	019f0871-5e20-7e31-d6d1-5b43508013e7	Red thread	2026-06-27 09:38:11.307983+00
019f3832-8d4d-7d35-a0f9-e3f3050265ee	019f085a-3064-70f4-7264-abe1b57813df	019f3832-5804-782a-700f-e1ec52a0d1a9	OrangeColor	2026-07-06 16:11:04.905581+00
019f384c-ef07-7fd7-c1a8-5cd505f45962	019f085a-3064-70f4-7264-abe1b57813df	019f3832-5804-782a-700f-e1ec52a0d1a9	Red color	2026-07-06 16:39:53.860423+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, email, password_hash, full_name, is_active, last_login_at, created_at, updated_at) FROM stdin;
019f085a-3064-70f4-7264-abe1b57813df	angayarkanni	angayarkanni834@gmail.com	$2y$10$oIfZP1gn.OJpqkI49qA5y.9gsY7du1zk59Y0UEwUNKNA7Kx6ob8JS	\N	t	\N	2026-06-27 09:12:36.189989+00	2026-06-27 09:12:36.189989+00
e165e33e-0b13-4db9-93bb-79858a78a74a	testuser	testuser@example.com	$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi	Test User	t	\N	2026-06-26 12:24:37.839725+00	2026-06-26 12:24:37.839725+00
\.


--
-- Data for Name: vendor_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendor_payments (id, user_id, purchase_id, amount, payment_date, created_at) FROM stdin;
360d7c8a-26c9-405f-ba34-469478fb52cf	019f085a-3064-70f4-7264-abe1b57813df	56a5625a-63a6-4db2-91ff-54a9b2990da7	18.00	2026-06-27 00:00:00+00	2026-06-27 09:41:34.373593+00
5f33742a-9488-4496-ade0-b5b250ecfcbf	019f085a-3064-70f4-7264-abe1b57813df	20290884-ca68-4a3f-9d3f-70cc01fcedcf	20.00	2026-06-30 00:00:00+00	2026-06-30 16:05:27.463451+00
bc5acd86-de30-4c47-86e8-342c4e202215	019f085a-3064-70f4-7264-abe1b57813df	c1995100-7a9f-4e85-b6a2-00a328803479	500.00	2026-07-06 00:00:00+00	2026-07-06 16:29:18.602173+00
\.


--
-- Data for Name: vendor_purchase_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendor_purchase_items (id, purchase_id, product_id, product_name_snapshot, quantity, unit_cost, gst_rate) FROM stdin;
63372f0b-4366-405c-8841-a08e89798a82	56a5625a-63a6-4db2-91ff-54a9b2990da7	019f0872-7e4a-7efe-75ef-27d1fe58fa7f	Gold stones T01	20.000	10.00	9.00
340af3f9-6a07-4769-bb7a-ffcf25863e76	20290884-ca68-4a3f-9d3f-70cc01fcedcf	019f13c6-d7f4-7716-a073-809189390517	Red thread T01	20.000	10.00	10.00
05aafd7c-3399-48d5-99f4-675dd84e0ddb	c294e2f9-153a-48ef-9df3-3c186da7c7f0	019f37dc-c782-775c-9a47-55c139b7f5f5	left footer	30.000	3000.00	30.00
dec8d543-c26b-43b7-b394-a1923495b640	5864b367-05cb-445a-8163-cebace9ccd39	019f3833-e982-7976-0867-1ff6efaa2223	Orange Color B01	30.000	1.67	16.00
2a301c84-f542-4d26-84e3-2788bf33f9ee	c1995100-7a9f-4e85-b6a2-00a328803479	019f3840-b80f-788e-d21f-57b23086d62a	Orange color B02	30.000	50.00	3.00
\.


--
-- Data for Name: vendor_purchases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendor_purchases (id, user_id, vendor_id, invoice_number, total_amount, amount_paid, purchase_date, created_at, updated_at) FROM stdin;
56a5625a-63a6-4db2-91ff-54a9b2990da7	019f085a-3064-70f4-7264-abe1b57813df	dc2d8373-63cd-4413-8452-c083a22a18b0	\N	200.00	218.00	2026-06-27 00:00:00+00	2026-06-27 09:41:05.770267+00	2026-06-27 09:41:34.373593+00
20290884-ca68-4a3f-9d3f-70cc01fcedcf	019f085a-3064-70f4-7264-abe1b57813df	73cbf140-2928-439a-aee9-b98da3eebf34	\N	200.00	220.00	2026-06-29 00:00:00+00	2026-06-29 14:29:42.511945+00	2026-06-30 16:05:27.463451+00
c294e2f9-153a-48ef-9df3-3c186da7c7f0	019f085a-3064-70f4-7264-abe1b57813df	dc2d8373-63cd-4413-8452-c083a22a18b0	\N	90000.00	70000.00	2026-07-06 00:00:00+00	2026-07-06 14:38:41.688294+00	2026-07-06 14:38:41.688294+00
5864b367-05cb-445a-8163-cebace9ccd39	019f085a-3064-70f4-7264-abe1b57813df	a28c74d9-4958-43f2-b8ea-89534c0ca374	\N	50.00	40.00	2026-07-06 00:00:00+00	2026-07-06 16:18:42.742302+00	2026-07-06 16:18:42.742302+00
c1995100-7a9f-4e85-b6a2-00a328803479	019f085a-3064-70f4-7264-abe1b57813df	a28c74d9-4958-43f2-b8ea-89534c0ca374	\N	1500.00	1500.00	2026-07-06 00:00:00+00	2026-07-06 16:28:22.503361+00	2026-07-06 16:29:18.602173+00
\.


--
-- Data for Name: vendors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendors (id, user_id, name, contact_info, created_at, updated_at) FROM stdin;
dc2d8373-63cd-4413-8452-c083a22a18b0	019f085a-3064-70f4-7264-abe1b57813df	aishwarya	7530019108	2026-06-27 09:41:05.765513+00	2026-06-27 09:41:05.765513+00
73cbf140-2928-439a-aee9-b98da3eebf34	019f085a-3064-70f4-7264-abe1b57813df	surya	9042357007	2026-06-29 14:29:42.50797+00	2026-06-29 14:29:42.50797+00
a28c74d9-4958-43f2-b8ea-89534c0ca374	019f085a-3064-70f4-7264-abe1b57813df	Angayarkanni	09884983412	2026-07-06 16:18:42.730158+00	2026-07-06 16:18:42.730158+00
\.


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.migrations_id_seq', 20, true);


--
-- Name: backup_config backup_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_config
    ADD CONSTRAINT backup_config_pkey PRIMARY KEY (id);


--
-- Name: backup_config backup_config_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_config
    ADD CONSTRAINT backup_config_user_id_key UNIQUE (user_id);


--
-- Name: backup_jobs backup_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_jobs
    ADD CONSTRAINT backup_jobs_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: categories categories_user_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_user_id_name_key UNIQUE (user_id, name);


--
-- Name: customer_ledger customer_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_ledger
    ADD CONSTRAINT customer_ledger_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: customers customers_user_id_phone_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_user_id_phone_key UNIQUE (user_id, phone);


--
-- Name: inventory_batches inventory_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_batches
    ADD CONSTRAINT inventory_batches_pkey PRIMARY KEY (id);


--
-- Name: invoice_items invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_pkey PRIMARY KEY (id);


--
-- Name: invoice_returns invoice_returns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_returns
    ADD CONSTRAINT invoice_returns_pkey PRIMARY KEY (id);


--
-- Name: invoice_sequences invoice_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_sequences
    ADD CONSTRAINT invoice_sequences_pkey PRIMARY KEY (id);


--
-- Name: invoice_sequences invoice_sequences_user_id_year_prefix_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_sequences
    ADD CONSTRAINT invoice_sequences_user_id_year_prefix_key UNIQUE (user_id, year, prefix);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_user_id_invoice_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_user_id_invoice_number_key UNIQUE (user_id, invoice_number);


--
-- Name: migrations migrations_filename_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_filename_key UNIQUE (filename);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: password_resets password_resets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_resets
    ADD CONSTRAINT password_resets_pkey PRIMARY KEY (id);


--
-- Name: password_resets password_resets_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_resets
    ADD CONSTRAINT password_resets_token_key UNIQUE (token);


--
-- Name: payment_receipt_sequences payment_receipt_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_receipt_sequences
    ADD CONSTRAINT payment_receipt_sequences_pkey PRIMARY KEY (id);


--
-- Name: payment_receipt_sequences payment_receipt_sequences_user_id_year_prefix_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_receipt_sequences
    ADD CONSTRAINT payment_receipt_sequences_user_id_year_prefix_key UNIQUE (user_id, year, prefix);


--
-- Name: payment_receipts payment_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_receipts
    ADD CONSTRAINT payment_receipts_pkey PRIMARY KEY (id);


--
-- Name: payment_receipts payment_receipts_user_id_receipt_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_receipts
    ADD CONSTRAINT payment_receipts_user_id_receipt_number_key UNIQUE (user_id, receipt_number);


--
-- Name: product_daily_sales product_daily_sales_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_daily_sales
    ADD CONSTRAINT product_daily_sales_pkey PRIMARY KEY (id);


--
-- Name: product_daily_sales product_daily_sales_user_id_product_id_sale_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_daily_sales
    ADD CONSTRAINT product_daily_sales_user_id_product_id_sale_date_key UNIQUE (user_id, product_id, sale_date);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: products products_user_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_user_id_name_key UNIQUE (user_id, name);


--
-- Name: purchases purchases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_pkey PRIMARY KEY (id);


--
-- Name: stock_list stock_list_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_list
    ADD CONSTRAINT stock_list_pkey PRIMARY KEY (id);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- Name: subcategories subcategories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subcategories
    ADD CONSTRAINT subcategories_pkey PRIMARY KEY (id);


--
-- Name: subcategories subcategories_user_id_category_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subcategories
    ADD CONSTRAINT subcategories_user_id_category_id_name_key UNIQUE (user_id, category_id, name);


--
-- Name: vendors unique_user_vendor; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT unique_user_vendor UNIQUE (user_id, name);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: vendor_payments vendor_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_payments
    ADD CONSTRAINT vendor_payments_pkey PRIMARY KEY (id);


--
-- Name: vendor_purchase_items vendor_purchase_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_purchase_items
    ADD CONSTRAINT vendor_purchase_items_pkey PRIMARY KEY (id);


--
-- Name: vendor_purchases vendor_purchases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_purchases
    ADD CONSTRAINT vendor_purchases_pkey PRIMARY KEY (id);


--
-- Name: vendors vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_pkey PRIMARY KEY (id);


--
-- Name: idx_backup_jobs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_backup_jobs_created_at ON public.backup_jobs USING btree (created_at DESC);


--
-- Name: idx_backup_jobs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_backup_jobs_status ON public.backup_jobs USING btree (status);


--
-- Name: idx_backup_jobs_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_backup_jobs_user_id ON public.backup_jobs USING btree (user_id);


--
-- Name: idx_categories_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_categories_name ON public.categories USING btree (name);


--
-- Name: idx_categories_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_categories_user ON public.categories USING btree (user_id);


--
-- Name: idx_cust_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cust_phone ON public.customers USING btree (user_id, phone);


--
-- Name: idx_cust_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cust_user_id ON public.customers USING btree (user_id);


--
-- Name: idx_customers_credit; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customers_credit ON public.customers USING btree (user_id, credit_limit) WHERE (status = 'active'::text);


--
-- Name: idx_inv_billed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_inv_billed_at ON public.invoices USING btree (user_id, billed_at);


--
-- Name: idx_inv_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_inv_customer ON public.invoices USING btree (customer_id);


--
-- Name: idx_inv_items_batch; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_inv_items_batch ON public.invoice_items USING btree (batch_id);


--
-- Name: idx_inv_items_invoice; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_inv_items_invoice ON public.invoice_items USING btree (invoice_id);


--
-- Name: idx_inv_items_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_inv_items_product ON public.invoice_items USING btree (product_id);


--
-- Name: idx_inv_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_inv_number ON public.invoices USING btree (user_id, invoice_number);


--
-- Name: idx_inv_payment_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_inv_payment_status ON public.invoices USING btree (payment_status);


--
-- Name: idx_inv_ret_invoice; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_inv_ret_invoice ON public.invoice_returns USING btree (invoice_id);


--
-- Name: idx_inv_ret_item; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_inv_ret_item ON public.invoice_returns USING btree (invoice_item_id);


--
-- Name: idx_inv_ret_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_inv_ret_product ON public.invoice_returns USING btree (product_id);


--
-- Name: idx_inv_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_inv_status ON public.invoices USING btree (invoice_status);


--
-- Name: idx_inv_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_inv_user_id ON public.invoices USING btree (user_id);


--
-- Name: idx_inventory_batches_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_inventory_batches_product_id ON public.inventory_batches USING btree (product_id);


--
-- Name: idx_inventory_batches_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_inventory_batches_user_id ON public.inventory_batches USING btree (user_id);


--
-- Name: idx_ledger_balance_filter; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ledger_balance_filter ON public.customer_ledger USING btree (user_id, balance DESC);


--
-- Name: idx_ledger_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ledger_customer ON public.customer_ledger USING btree (customer_id);


--
-- Name: idx_ledger_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ledger_user ON public.customer_ledger USING btree (user_id);


--
-- Name: idx_password_resets_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_password_resets_expires ON public.password_resets USING btree (expires_at);


--
-- Name: idx_password_resets_token; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_password_resets_token ON public.password_resets USING btree (token);


--
-- Name: idx_password_resets_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_password_resets_user ON public.password_resets USING btree (user_id);


--
-- Name: idx_payment_receipts_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payment_receipts_customer ON public.payment_receipts USING btree (user_id, customer_id);


--
-- Name: idx_payment_receipts_ledger; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payment_receipts_ledger ON public.payment_receipts USING btree (ledger_id);


--
-- Name: idx_payment_receipts_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payment_receipts_number ON public.payment_receipts USING btree (user_id, receipt_number);


--
-- Name: idx_pds_product_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pds_product_date ON public.product_daily_sales USING btree (product_id, sale_date);


--
-- Name: idx_pds_user_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pds_user_date ON public.product_daily_sales USING btree (user_id, sale_date);


--
-- Name: idx_products_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_category ON public.products USING btree (category_id);


--
-- Name: idx_products_gst; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_gst ON public.products USING btree (gst_rate);


--
-- Name: idx_products_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_name ON public.products USING btree (name);


--
-- Name: idx_products_subcategory; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_subcategory ON public.products USING btree (subcategory_id);


--
-- Name: idx_products_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_user ON public.products USING btree (user_id);


--
-- Name: idx_purchases_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_purchases_created_at ON public.purchases USING btree (created_at);


--
-- Name: idx_purchases_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_purchases_user_id ON public.purchases USING btree (user_id);


--
-- Name: idx_seq_user_year; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_seq_user_year ON public.invoice_sequences USING btree (user_id, year);


--
-- Name: idx_stock_list_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_list_product_id ON public.stock_list USING btree (product_id);


--
-- Name: idx_stock_mvmt_batch; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_mvmt_batch ON public.stock_movements USING btree (batch_id);


--
-- Name: idx_stock_mvmt_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_mvmt_product ON public.stock_movements USING btree (product_id);


--
-- Name: idx_stock_mvmt_ref; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_mvmt_ref ON public.stock_movements USING btree (reference_type, reference_id);


--
-- Name: idx_stock_mvmt_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_mvmt_user ON public.stock_movements USING btree (user_id, created_at);


--
-- Name: idx_subcategories_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subcategories_category ON public.subcategories USING btree (category_id);


--
-- Name: idx_subcategories_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subcategories_name ON public.subcategories USING btree (name);


--
-- Name: idx_subcategories_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subcategories_user ON public.subcategories USING btree (user_id);


--
-- Name: idx_users_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_active ON public.users USING btree (is_active) WHERE (is_active = true);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: idx_vp_user_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vp_user_date ON public.vendor_purchases USING btree (user_id, purchase_date);


--
-- Name: idx_vp_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vp_user_id ON public.vendor_purchases USING btree (user_id);


--
-- Name: idx_vp_vendor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vp_vendor_id ON public.vendor_purchases USING btree (vendor_id);


--
-- Name: idx_vpi_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vpi_product_id ON public.vendor_purchase_items USING btree (product_id);


--
-- Name: idx_vpi_purchase_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vpi_purchase_id ON public.vendor_purchase_items USING btree (purchase_id);


--
-- Name: idx_vpymt_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vpymt_date ON public.vendor_payments USING btree (user_id, payment_date);


--
-- Name: idx_vpymt_purchase_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vpymt_purchase_id ON public.vendor_payments USING btree (purchase_id);


--
-- Name: idx_vpymt_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vpymt_user_id ON public.vendor_payments USING btree (user_id);


--
-- Name: backup_config backup_config_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_config
    ADD CONSTRAINT backup_config_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: backup_jobs backup_jobs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_jobs
    ADD CONSTRAINT backup_jobs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: categories categories_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: customer_ledger customer_ledger_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_ledger
    ADD CONSTRAINT customer_ledger_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: customer_ledger customer_ledger_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_ledger
    ADD CONSTRAINT customer_ledger_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE SET NULL;


--
-- Name: customer_ledger customer_ledger_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_ledger
    ADD CONSTRAINT customer_ledger_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: customers customers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: inventory_batches inventory_batches_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_batches
    ADD CONSTRAINT inventory_batches_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: inventory_batches inventory_batches_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_batches
    ADD CONSTRAINT inventory_batches_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: invoice_items invoice_items_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.inventory_batches(id) ON DELETE SET NULL;


--
-- Name: invoice_items invoice_items_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: invoice_items invoice_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE RESTRICT;


--
-- Name: invoice_returns invoice_returns_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_returns
    ADD CONSTRAINT invoice_returns_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.inventory_batches(id) ON DELETE SET NULL;


--
-- Name: invoice_returns invoice_returns_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_returns
    ADD CONSTRAINT invoice_returns_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE RESTRICT;


--
-- Name: invoice_returns invoice_returns_invoice_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_returns
    ADD CONSTRAINT invoice_returns_invoice_item_id_fkey FOREIGN KEY (invoice_item_id) REFERENCES public.invoice_items(id) ON DELETE SET NULL;


--
-- Name: invoice_returns invoice_returns_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_returns
    ADD CONSTRAINT invoice_returns_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE RESTRICT;


--
-- Name: invoice_sequences invoice_sequences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_sequences
    ADD CONSTRAINT invoice_sequences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: invoices invoices_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: invoices invoices_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: password_resets password_resets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_resets
    ADD CONSTRAINT password_resets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payment_receipt_sequences payment_receipt_sequences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_receipt_sequences
    ADD CONSTRAINT payment_receipt_sequences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payment_receipts payment_receipts_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_receipts
    ADD CONSTRAINT payment_receipts_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: payment_receipts payment_receipts_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_receipts
    ADD CONSTRAINT payment_receipts_ledger_id_fkey FOREIGN KEY (ledger_id) REFERENCES public.customer_ledger(id) ON DELETE RESTRICT;


--
-- Name: payment_receipts payment_receipts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_receipts
    ADD CONSTRAINT payment_receipts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: product_daily_sales product_daily_sales_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_daily_sales
    ADD CONSTRAINT product_daily_sales_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_daily_sales product_daily_sales_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_daily_sales
    ADD CONSTRAINT product_daily_sales_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: products products_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE RESTRICT;


--
-- Name: products products_subcategory_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_subcategory_id_fkey FOREIGN KEY (subcategory_id) REFERENCES public.subcategories(id) ON DELETE SET NULL;


--
-- Name: products products_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: purchases purchases_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: stock_list stock_list_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_list
    ADD CONSTRAINT stock_list_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: stock_list stock_list_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_list
    ADD CONSTRAINT stock_list_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.inventory_batches(id) ON DELETE SET NULL;


--
-- Name: stock_movements stock_movements_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE RESTRICT;


--
-- Name: stock_movements stock_movements_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: subcategories subcategories_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subcategories
    ADD CONSTRAINT subcategories_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: subcategories subcategories_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subcategories
    ADD CONSTRAINT subcategories_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: vendor_payments vendor_payments_purchase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_payments
    ADD CONSTRAINT vendor_payments_purchase_id_fkey FOREIGN KEY (purchase_id) REFERENCES public.vendor_purchases(id) ON DELETE CASCADE;


--
-- Name: vendor_payments vendor_payments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_payments
    ADD CONSTRAINT vendor_payments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: vendor_purchase_items vendor_purchase_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_purchase_items
    ADD CONSTRAINT vendor_purchase_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE RESTRICT;


--
-- Name: vendor_purchase_items vendor_purchase_items_purchase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_purchase_items
    ADD CONSTRAINT vendor_purchase_items_purchase_id_fkey FOREIGN KEY (purchase_id) REFERENCES public.vendor_purchases(id) ON DELETE CASCADE;


--
-- Name: vendor_purchases vendor_purchases_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_purchases
    ADD CONSTRAINT vendor_purchases_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: vendor_purchases vendor_purchases_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_purchases
    ADD CONSTRAINT vendor_purchases_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.vendors(id) ON DELETE RESTRICT;


--
-- Name: vendors vendors_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: backup_config Users can access their own backup config; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can access their own backup config" ON public.backup_config USING ((user_id = (current_setting('app.current_user_id'::text, true))::uuid));


--
-- Name: backup_jobs Users can access their own backup jobs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can access their own backup jobs" ON public.backup_jobs USING ((user_id = (current_setting('app.current_user_id'::text, true))::uuid));


--
-- Name: inventory_batches Users can access their own inventory batches; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can access their own inventory batches" ON public.inventory_batches USING ((user_id = (current_setting('app.current_user_id'::text, true))::uuid));


--
-- Name: purchases Users can access their own purchases; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can access their own purchases" ON public.purchases USING ((user_id = (current_setting('app.current_user_id'::text, true))::uuid));


--
-- Name: stock_list Users can access their own stock list; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can access their own stock list" ON public.stock_list USING ((user_id = (current_setting('app.current_user_id'::text, true))::uuid));


--
-- Name: backup_config; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.backup_config ENABLE ROW LEVEL SECURITY;

--
-- Name: backup_jobs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.backup_jobs ENABLE ROW LEVEL SECURITY;

--
-- Name: customer_ledger; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.customer_ledger ENABLE ROW LEVEL SECURITY;

--
-- Name: customer_ledger customer_ledger_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY customer_ledger_isolation ON public.customer_ledger USING ((user_id = (current_setting('app.current_user_id'::text, true))::uuid)) WITH CHECK ((user_id = (current_setting('app.current_user_id'::text, true))::uuid));


--
-- Name: customers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;

--
-- Name: customers customers_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY customers_isolation ON public.customers USING ((user_id = (current_setting('app.current_user_id'::text, true))::uuid)) WITH CHECK ((user_id = (current_setting('app.current_user_id'::text, true))::uuid));


--
-- Name: inventory_batches; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.inventory_batches ENABLE ROW LEVEL SECURITY;

--
-- Name: invoice_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.invoice_items ENABLE ROW LEVEL SECURITY;

--
-- Name: invoice_items invoice_items_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY invoice_items_isolation ON public.invoice_items USING ((EXISTS ( SELECT 1
   FROM public.invoices
  WHERE ((invoices.id = invoice_items.invoice_id) AND (invoices.user_id = (current_setting('app.current_user_id'::text, true))::uuid)))));


--
-- Name: invoice_returns; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.invoice_returns ENABLE ROW LEVEL SECURITY;

--
-- Name: invoice_returns invoice_returns_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY invoice_returns_isolation ON public.invoice_returns USING ((EXISTS ( SELECT 1
   FROM public.invoices
  WHERE ((invoices.id = invoice_returns.invoice_id) AND (invoices.user_id = (current_setting('app.current_user_id'::text, true))::uuid)))));


--
-- Name: invoice_sequences; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.invoice_sequences ENABLE ROW LEVEL SECURITY;

--
-- Name: invoice_sequences invoice_sequences_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY invoice_sequences_isolation ON public.invoice_sequences USING ((user_id = (current_setting('app.current_user_id'::text, true))::uuid)) WITH CHECK ((user_id = (current_setting('app.current_user_id'::text, true))::uuid));


--
-- Name: invoices; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.invoices ENABLE ROW LEVEL SECURITY;

--
-- Name: invoices invoices_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY invoices_isolation ON public.invoices USING ((user_id = (current_setting('app.current_user_id'::text, true))::uuid)) WITH CHECK ((user_id = (current_setting('app.current_user_id'::text, true))::uuid));


--
-- Name: payment_receipt_sequences; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.payment_receipt_sequences ENABLE ROW LEVEL SECURITY;

--
-- Name: payment_receipt_sequences payment_receipt_sequences_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY payment_receipt_sequences_isolation ON public.payment_receipt_sequences USING ((user_id = (current_setting('app.current_user_id'::text, true))::uuid)) WITH CHECK ((user_id = (current_setting('app.current_user_id'::text, true))::uuid));


--
-- Name: payment_receipts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.payment_receipts ENABLE ROW LEVEL SECURITY;

--
-- Name: payment_receipts payment_receipts_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY payment_receipts_isolation ON public.payment_receipts USING ((user_id = (current_setting('app.current_user_id'::text, true))::uuid)) WITH CHECK ((user_id = (current_setting('app.current_user_id'::text, true))::uuid));


--
-- Name: product_daily_sales pds_user_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY pds_user_isolation ON public.product_daily_sales USING ((user_id = (current_setting('app.current_user_id'::text))::uuid));


--
-- Name: product_daily_sales; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.product_daily_sales ENABLE ROW LEVEL SECURITY;

--
-- Name: purchases; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.purchases ENABLE ROW LEVEL SECURITY;

--
-- Name: stock_list; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.stock_list ENABLE ROW LEVEL SECURITY;

--
-- Name: stock_movements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.stock_movements ENABLE ROW LEVEL SECURITY;

--
-- Name: stock_movements stock_movements_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY stock_movements_isolation ON public.stock_movements USING ((user_id = (current_setting('app.current_user_id'::text, true))::uuid)) WITH CHECK ((user_id = (current_setting('app.current_user_id'::text, true))::uuid));


--
-- Name: vendor_payments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.vendor_payments ENABLE ROW LEVEL SECURITY;

--
-- Name: vendor_payments vendor_payments_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY vendor_payments_isolation ON public.vendor_payments USING ((user_id = (current_setting('app.current_user_id'::text, true))::uuid)) WITH CHECK ((user_id = (current_setting('app.current_user_id'::text, true))::uuid));


--
-- Name: vendor_purchases; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.vendor_purchases ENABLE ROW LEVEL SECURITY;

--
-- Name: vendor_purchases vendor_purchases_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY vendor_purchases_isolation ON public.vendor_purchases USING ((user_id = (current_setting('app.current_user_id'::text, true))::uuid)) WITH CHECK ((user_id = (current_setting('app.current_user_id'::text, true))::uuid));


--
-- Name: vendors; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.vendors ENABLE ROW LEVEL SECURITY;

--
-- Name: vendors vendors_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY vendors_isolation ON public.vendors USING ((user_id = (current_setting('app.current_user_id'::text, true))::uuid)) WITH CHECK ((user_id = (current_setting('app.current_user_id'::text, true))::uuid));


--
-- PostgreSQL database dump complete
--

\unrestrict wRMV5jpU0gEG9M2Pe0iB3m1wahmMr6WuL13DXCRfNNzQp2umKqM3KR8aUF8wa0d

